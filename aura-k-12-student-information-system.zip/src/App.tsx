/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SISProvider, useSIS } from './context/SISContext';
import { TopNavigation } from './components/TopNavigation';
import { CommandPalette } from './components/CommandPalette';
import { OverviewDashboard } from './components/Dashboard/OverviewDashboard';
import { StudentDirectory } from './components/Enrollment/StudentDirectory';
import { GradebookView } from './components/Gradebook/GradebookView';
import { AttendanceModule } from './components/Attendance/AttendanceModule';
import { ParentPortalView } from './components/ParentPortal/ParentPortalView';
import { StateReportingView } from './components/StateReporting/StateReportingView';

const MainContent: React.FC = () => {
  const { activeModule, currentRole } = useSIS();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <TopNavigation />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeModule === 'dashboard' && <OverviewDashboard />}
        {activeModule === 'enrollment' && <StudentDirectory />}
        {activeModule === 'gradebook' && <GradebookView />}
        {activeModule === 'attendance' && <AttendanceModule />}
        {activeModule === 'parent_portal' && <ParentPortalView />}
        {activeModule === 'state_reporting' && <StateReportingView />}
      </main>

      {/* Modern, quiet footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">Aura K-12 Student Information System</span>
            <span>·</span>
            <span>Oakridge Unified School District</span>
            <span>·</span>
            <span className="font-mono">FERPA & Ed-Fi Compliant</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Version 2.4.1</span>
            <span>·</span>
            <span>State Census 2026 Ready</span>
          </div>
        </div>
      </footer>

      {/* Global Command Palette */}
      <CommandPalette />
    </div>
  );
};

export default function App() {
  return (
    <SISProvider>
      <MainContent />
    </SISProvider>
  );
}
