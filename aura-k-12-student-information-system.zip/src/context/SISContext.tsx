import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Student,
  Course,
  Assignment,
  GradeEntry,
  AttendanceRecord,
  ParentAbsenceNote,
  ComplianceValidationRule,
  UserRole,
  ActiveModule,
  AttendanceStatusCode,
} from '../types/sis';
import {
  INITIAL_STUDENTS,
  INITIAL_COURSES,
  INITIAL_ASSIGNMENTS,
  INITIAL_GRADES,
  INITIAL_ATTENDANCE,
  INITIAL_ABSENCE_NOTES,
  STATE_VALIDATION_RULES,
} from '../data/mockData';

interface SISContextType {
  students: Student[];
  courses: Course[];
  assignments: Assignment[];
  grades: GradeEntry[];
  attendance: AttendanceRecord[];
  absenceNotes: ParentAbsenceNote[];
  validationRules: ComplianceValidationRule[];
  currentRole: UserRole;
  activeModule: ActiveModule;
  selectedStudentId: string | null;
  selectedParentStudentId: string;
  selectedCourseId: string;
  selectedDate: string;
  selectedPeriod: number | 'homeroom';
  searchQuery: string;
  commandPaletteOpen: boolean;

  setRole: (role: UserRole) => void;
  setActiveModule: (mod: ActiveModule) => void;
  setSelectedStudentId: (id: string | null) => void;
  setSelectedParentStudentId: (id: string) => void;
  setSelectedCourseId: (id: string) => void;
  setSelectedDate: (date: string) => void;
  setSelectedPeriod: (period: number | 'homeroom') => void;
  setSearchQuery: (query: string) => void;
  setCommandPaletteOpen: (open: boolean) => void;

  enrollStudent: (newStudent: Omit<Student, 'id' | 'cumulativeGpa' | 'creditsEarned' | 'attendanceRate'>) => Student;
  updateStudent: (id: string, updates: Partial<Student>) => void;
  verifyDocument: (studentId: string, docId: string, verified: boolean, notes?: string) => void;
  addAssignment: (assignment: Omit<Assignment, 'id'>) => Assignment;
  updateGrade: (
    studentId: string,
    assignmentId: string,
    score: number | null,
    standardMastery?: 1 | 2 | 3 | 4,
    feedback?: string
  ) => void;
  setAttendanceStatus: (
    studentId: string,
    date: string,
    period: number | 'homeroom',
    status: AttendanceStatusCode,
    notes?: string
  ) => void;
  markAllPresent: (date: string, period: number | 'homeroom', studentIds: string[]) => void;
  submitParentAbsenceNote: (note: Omit<ParentAbsenceNote, 'id' | 'status'>) => void;
  updateAbsenceNoteStatus: (noteId: string, status: 'Approved' | 'Declined', reviewer: string) => void;
  fixStudentSSID: (studentId: string, ssid: string) => void;
  resetToDemoData: () => void;
}

const SISContext = createContext<SISContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'aura_sis_';

function loadOr<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PREFIX + key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (err) {
    console.error('Failed to load from localStorage', err);
    return fallback;
  }
}

export const SISProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [students, setStudents] = useState<Student[]>(() => loadOr('students', INITIAL_STUDENTS));
  const [courses, setCourses] = useState<Course[]>(() => loadOr('courses', INITIAL_COURSES));
  const [assignments, setAssignments] = useState<Assignment[]>(() => loadOr('assignments', INITIAL_ASSIGNMENTS));
  const [grades, setGrades] = useState<GradeEntry[]>(() => loadOr('grades', INITIAL_GRADES));
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => loadOr('attendance', INITIAL_ATTENDANCE));
  const [absenceNotes, setAbsenceNotes] = useState<ParentAbsenceNote[]>(() => loadOr('notes', INITIAL_ABSENCE_NOTES));
  const [validationRules, setValidationRules] = useState<ComplianceValidationRule[]>(() => loadOr('rules', STATE_VALIDATION_RULES));

  const [currentRole, setCurrentRole] = useState<UserRole>('admin');
  const [activeModule, setActiveModule] = useState<ActiveModule>('dashboard');
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [selectedParentStudentId, setSelectedParentStudentId] = useState<string>('stu-101'); // Maya Lin
  const [selectedCourseId, setSelectedCourseId] = useState<string>('crs-bio10');
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-29');
  const [selectedPeriod, setSelectedPeriod] = useState<number | 'homeroom'>(1);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [commandPaletteOpen, setCommandPaletteOpen] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'students', JSON.stringify(students));
  }, [students]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'assignments', JSON.stringify(assignments));
  }, [assignments]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'grades', JSON.stringify(grades));
  }, [grades]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'attendance', JSON.stringify(attendance));
  }, [attendance]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'notes', JSON.stringify(absenceNotes));
  }, [absenceNotes]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'rules', JSON.stringify(validationRules));
  }, [validationRules]);

  // Keyboard shortcut for Cmd+K command bar
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const enrollStudent = (newStudentData: Omit<Student, 'id' | 'cumulativeGpa' | 'creditsEarned' | 'attendanceRate'>): Student => {
    const newId = `stu-${Date.now().toString().slice(-4)}`;
    const student: Student = {
      ...newStudentData,
      id: newId,
      cumulativeGpa: 4.0,
      creditsEarned: newStudentData.gradeLevel === 'K' || parseInt(newStudentData.gradeLevel) < 9 ? 0 : 5,
      attendanceRate: 100.0,
    };
    setStudents((prev) => [student, ...prev]);
    return student;
  };

  const updateStudent = (id: string, updates: Partial<Student>) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updates } : s))
    );
  };

  const verifyDocument = (studentId: string, docId: string, verified: boolean, notes?: string) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id !== studentId) return s;
        return {
          ...s,
          documents: s.documents.map((d) =>
            d.id === docId
              ? {
                  ...d,
                  verified,
                  notes: notes || d.notes,
                  verificationDate: verified ? new Date().toISOString().split('T')[0] : undefined,
                  verifiedBy: verified ? 'K. Patel (Registrar)' : undefined,
                }
              : d
          ),
        };
      })
    );
  };

  const addAssignment = (assignmentData: Omit<Assignment, 'id'>): Assignment => {
    const newId = `asg-${Date.now().toString().slice(-5)}`;
    const newAsg: Assignment = {
      ...assignmentData,
      id: newId,
    };
    setAssignments((prev) => [...prev, newAsg]);
    return newAsg;
  };

  const updateGrade = (
    studentId: string,
    assignmentId: string,
    score: number | null,
    standardMastery?: 1 | 2 | 3 | 4,
    feedback?: string
  ) => {
    setGrades((prev) => {
      const existingIndex = prev.findIndex(
        (g) => g.studentId === studentId && g.assignmentId === assignmentId
      );
      if (existingIndex >= 0) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          score,
          standardMastery,
          feedback: feedback !== undefined ? feedback : updated[existingIndex].feedback,
        };
        return updated;
      } else {
        const asg = assignments.find((a) => a.id === assignmentId);
        const newEntry: GradeEntry = {
          id: `g-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          studentId,
          assignmentId,
          courseId: asg ? asg.courseId : selectedCourseId,
          score,
          standardMastery,
          feedback,
          submittedAt: new Date().toISOString(),
        };
        return [...prev, newEntry];
      }
    });
  };

  const setAttendanceStatus = (
    studentId: string,
    date: string,
    period: number | 'homeroom',
    status: AttendanceStatusCode,
    notes?: string
  ) => {
    setAttendance((prev) => {
      const existingIndex = prev.findIndex(
        (a) => a.studentId === studentId && a.date === date && a.period === period
      );
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      if (existingIndex >= 0) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          status,
          notes: notes !== undefined ? notes : updated[existingIndex].notes,
          markedAt: timeStr,
        };
        return updated;
      } else {
        const newRecord: AttendanceRecord = {
          id: `att-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          studentId,
          date,
          period,
          status,
          markedBy: currentRole === 'teacher' ? 'M. Henderson' : 'Attendance Office',
          markedAt: timeStr,
          notes,
        };
        return [...prev, newRecord];
      }
    });
  };

  const markAllPresent = (date: string, period: number | 'homeroom', studentIds: string[]) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setAttendance((prev) => {
      const recordsMap = new Map(
        prev.map((r) => [`${r.studentId}_${r.date}_${r.period}`, r])
      );
      studentIds.forEach((sId) => {
        const key = `${sId}_${date}_${period}`;
        recordsMap.set(key, {
          id: recordsMap.get(key)?.id || `att-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          studentId: sId,
          date,
          period,
          status: 'present',
          markedBy: currentRole === 'teacher' ? 'M. Henderson' : 'Attendance Office',
          markedAt: timeStr,
        });
      });
      return Array.from(recordsMap.values());
    });
  };

  const submitParentAbsenceNote = (noteData: Omit<ParentAbsenceNote, 'id' | 'status'>) => {
    const newNote: ParentAbsenceNote = {
      ...noteData,
      id: `note-${Date.now().toString().slice(-4)}`,
      status: 'Pending',
    };
    setAbsenceNotes((prev) => [newNote, ...prev]);
  };

  const updateAbsenceNoteStatus = (noteId: string, status: 'Approved' | 'Declined', reviewer: string) => {
    const timeStr = new Date().toLocaleString();
    setAbsenceNotes((prev) =>
      prev.map((n) => (n.id === noteId ? { ...n, status, reviewedBy: reviewer, reviewedAt: timeStr } : n))
    );
  };

  const fixStudentSSID = (studentId: string, ssid: string) => {
    updateStudent(studentId, { ssid, enrollmentStatus: 'Active' });
    // Clear fatal rule for this student
    setValidationRules((prev) =>
      prev.map((r) => {
        if (r.affectedStudentIds.includes(studentId)) {
          const remaining = r.affectedStudentIds.filter((id) => id !== studentId);
          return {
            ...r,
            affectedStudentIds: remaining,
            affectedCount: remaining.length,
          };
        }
        return r;
      })
    );
  };

  const resetToDemoData = () => {
    localStorage.clear();
    setStudents(INITIAL_STUDENTS);
    setCourses(INITIAL_COURSES);
    setAssignments(INITIAL_ASSIGNMENTS);
    setGrades(INITIAL_GRADES);
    setAttendance(INITIAL_ATTENDANCE);
    setAbsenceNotes(INITIAL_ABSENCE_NOTES);
    setValidationRules(STATE_VALIDATION_RULES);
  };

  return (
    <SISContext.Provider
      value={{
        students,
        courses,
        assignments,
        grades,
        attendance,
        absenceNotes,
        validationRules,
        currentRole,
        activeModule,
        selectedStudentId,
        selectedParentStudentId,
        selectedCourseId,
        selectedDate,
        selectedPeriod,
        searchQuery,
        commandPaletteOpen,

        setRole: setCurrentRole,
        setActiveModule,
        setSelectedStudentId,
        setSelectedParentStudentId,
        setSelectedCourseId,
        setSelectedDate,
        setSelectedPeriod,
        setSearchQuery,
        setCommandPaletteOpen,

        enrollStudent,
        updateStudent,
        verifyDocument,
        addAssignment,
        updateGrade,
        setAttendanceStatus,
        markAllPresent,
        submitParentAbsenceNote,
        updateAbsenceNoteStatus,
        fixStudentSSID,
        resetToDemoData,
      }}
    >
      {children}
    </SISContext.Provider>
  );
};

export const useSIS = () => {
  const context = useContext(SISContext);
  if (!context) {
    throw new Error('useSIS must be used within a SISProvider');
  }
  return context;
};
