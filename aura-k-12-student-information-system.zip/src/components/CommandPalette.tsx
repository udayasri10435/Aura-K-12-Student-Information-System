import React, { useState, useEffect, useRef } from 'react';
import { useSIS } from '../context/SISContext';
import { Search, X, User, BookOpen, Calendar, AlertTriangle, ArrowRight } from 'lucide-react';

export const CommandPalette: React.FC = () => {
  const {
    commandPaletteOpen,
    setCommandPaletteOpen,
    students,
    courses,
    validationRules,
    setSelectedStudentId,
    setActiveModule,
    setSelectedCourseId,
  } = useSIS();

  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (commandPaletteOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [commandPaletteOpen]);

  if (!commandPaletteOpen) return null;

  const filteredStudents = query.trim()
    ? students.filter(
        (s) =>
          `${s.firstName} ${s.lastName}`.toLowerCase().includes(query.toLowerCase()) ||
          s.localId.includes(query) ||
          s.ssid.toLowerCase().includes(query.toLowerCase())
      )
    : students.slice(0, 4);

  const filteredCourses = query.trim()
    ? courses.filter(
        (c) =>
          c.name.toLowerCase().includes(query.toLowerCase()) ||
          c.code.toLowerCase().includes(query.toLowerCase()) ||
          c.teacherName.toLowerCase().includes(query.toLowerCase())
      )
    : courses.slice(0, 3);

  const filteredAudits = query.trim()
    ? validationRules.filter(
        (r) =>
          r.description.toLowerCase().includes(query.toLowerCase()) ||
          r.ruleCode.toLowerCase().includes(query.toLowerCase())
      )
    : validationRules.slice(0, 2);

  const handleSelectStudent = (id: string) => {
    setSelectedStudentId(id);
    setActiveModule('enrollment');
    setCommandPaletteOpen(false);
  };

  const handleSelectCourse = (id: string) => {
    setSelectedCourseId(id);
    setActiveModule('gradebook');
    setCommandPaletteOpen(false);
  };

  const handleSelectCompliance = () => {
    setActiveModule('state_reporting');
    setCommandPaletteOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-slate-900/40 backdrop-blur-xs">
      <div
        className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center px-4 py-3 border-b border-slate-200 gap-3">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search students by name or ID, courses, or compliance audits..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent border-0 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none"
          />
          <button
            onClick={() => setCommandPaletteOpen(false)}
            className="p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-4">
          {/* Quick Actions */}
          {!query && (
            <div>
              <p className="px-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                Quick Navigation
              </p>
              <div className="mt-1 grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                <button
                  onClick={() => {
                    setActiveModule('enrollment');
                    setCommandPaletteOpen(false);
                  }}
                  className="flex items-center gap-2 p-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-md transition-colors text-left cursor-pointer"
                >
                  <User className="w-4 h-4 text-indigo-600" />
                  <span>Student Directory</span>
                </button>
                <button
                  onClick={() => {
                    setActiveModule('attendance');
                    setCommandPaletteOpen(false);
                  }}
                  className="flex items-center gap-2 p-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-md transition-colors text-left cursor-pointer"
                >
                  <Calendar className="w-4 h-4 text-emerald-600" />
                  <span>Take Attendance</span>
                </button>
                <button
                  onClick={() => {
                    setActiveModule('state_reporting');
                    setCommandPaletteOpen(false);
                  }}
                  className="flex items-center gap-2 p-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-md transition-colors text-left cursor-pointer"
                >
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>State Reporting Audit</span>
                </button>
              </div>
            </div>
          )}

          {/* Students Section */}
          {filteredStudents.length > 0 && (
            <div>
              <p className="px-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                Students
              </p>
              <div className="mt-1 space-y-0.5">
                {filteredStudents.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => handleSelectStudent(s.id)}
                    className="w-full flex items-center justify-between p-2 hover:bg-indigo-50/70 rounded-md transition-colors text-left group cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-semibold text-slate-700">
                        {s.firstName[0]}
                        {s.lastName[0]}
                      </div>
                      <div>
                        <p className="text-xs font-medium text-slate-900 group-hover:text-indigo-900">
                          {s.firstName} {s.lastName}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Grade {s.gradeLevel} · ID #{s.localId} · {s.homeroom}
                        </p>
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-indigo-600 opacity-0 group-hover:opacity-100 transition-all" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Courses Section */}
          {filteredCourses.length > 0 && (
            <div>
              <p className="px-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                Courses & Classes
              </p>
              <div className="mt-1 space-y-0.5">
                {filteredCourses.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => handleSelectCourse(c.id)}
                    className="w-full flex items-center justify-between p-2 hover:bg-slate-100 rounded-md transition-colors text-left group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <BookOpen className="w-4 h-4 text-slate-400 group-hover:text-indigo-600" />
                      <div>
                        <p className="text-xs font-medium text-slate-900">
                          {c.name}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Period {c.period} · {c.teacherName} · {c.room}
                        </p>
                      </div>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">
                      {c.code}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Compliance section */}
          {filteredAudits.length > 0 && (
            <div>
              <p className="px-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                State Compliance Rules
              </p>
              <div className="mt-1 space-y-0.5">
                {filteredAudits.map((r) => (
                  <button
                    key={r.id}
                    onClick={handleSelectCompliance}
                    className="w-full flex items-center justify-between p-2 hover:bg-amber-50/70 rounded-md transition-colors text-left group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                      <div>
                        <p className="text-xs font-medium text-slate-900">
                          {r.ruleCode}: {r.category}
                        </p>
                        <p className="text-[11px] text-slate-500 line-clamp-1">
                          {r.description}
                        </p>
                      </div>
                    </div>
                    <span className="text-[11px] font-mono text-amber-700">
                      {r.affectedCount} student{r.affectedCount > 1 ? 's' : ''}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {filteredStudents.length === 0 && filteredCourses.length === 0 && (
            <div className="py-8 text-center text-xs text-slate-500">
              No matching students, courses, or compliance records found.
            </div>
          )}
        </div>

        <div className="px-4 py-2 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <span>Press ESC to dismiss</span>
          <span>Aura K-12 Rapid Command</span>
        </div>
      </div>
    </div>
  );
};
