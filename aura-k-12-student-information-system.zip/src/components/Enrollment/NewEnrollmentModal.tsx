import React, { useState } from 'react';
import { useSIS } from '../../context/SISContext';
import { X, Check, AlertCircle } from 'lucide-react';
import { SchoolLevel, StudentDocument } from '../../types/sis';

interface NewEnrollmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewEnrollmentModal: React.FC<NewEnrollmentModalProps> = ({ isOpen, onClose }) => {
  const { enrollStudent, setSelectedStudentId } = useSIS();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [preferredName, setPreferredName] = useState('');
  const [dob, setDob] = useState('2011-05-18');
  const [gender, setGender] = useState<'Female' | 'Male' | 'Non-Binary' | 'Prefer not to say'>('Female');
  const [gradeLevel, setGradeLevel] = useState('9');
  const [schoolLevel, setSchoolLevel] = useState<SchoolLevel>('High');
  const [homeroom, setHomeroom] = useState('Room 102 (Mr. Garcia)');
  const [counselor, setCounselor] = useState('Elena Vance, MSW');
  const [ssid, setSsid] = useState('CA-9041289' + Math.floor(10 + Math.random() * 89));
  const [localId, setLocalId] = useState('11' + Math.floor(100 + Math.random() * 899));

  // Guardian
  const [guardianName, setGuardianName] = useState('');
  const [guardianRelation, setGuardianRelation] = useState<'Mother' | 'Father' | 'Legal Guardian'>('Mother');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [guardianEmail, setGuardianEmail] = useState('');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('Oakridge');
  const [state, setState] = useState('CA');
  const [zip, setZip] = useState('94025');

  // Emergency Contact
  const [emergName, setEmergName] = useState('');
  const [emergPhone, setEmergPhone] = useState('');

  // Programs
  const [iep, setIep] = useState(false);
  const [section504, setSection504] = useState(false);
  const [ell, setEll] = useState(false);
  const [primaryLanguage, setPrimaryLanguage] = useState('English');
  const [freeReducedLunch, setFreeReducedLunch] = useState(false);
  const [giftedTalented, setGiftedTalented] = useState(false);

  // Documents
  const [birthCertVerified, setBirthCertVerified] = useState(true);
  const [immunizationVerified, setImmunizationVerified] = useState(true);
  const [residencyVerified, setResidencyVerified] = useState(true);
  const [medicalNotes, setMedicalNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !lastName || !guardianName) {
      alert('Please fill in student name and primary guardian information.');
      return;
    }

    const docs: StudentDocument[] = [
      {
        id: 'd1',
        type: 'Birth Certificate',
        verified: birthCertVerified,
        verificationDate: birthCertVerified ? new Date().toISOString().split('T')[0] : undefined,
        verifiedBy: birthCertVerified ? 'Registrar Office' : undefined,
      },
      {
        id: 'd2',
        type: 'Immunization Records',
        verified: immunizationVerified,
        verificationDate: immunizationVerified ? new Date().toISOString().split('T')[0] : undefined,
        verifiedBy: immunizationVerified ? 'Nurse Daniels' : undefined,
      },
      {
        id: 'd3',
        type: 'Proof of Residency',
        verified: residencyVerified,
        verificationDate: residencyVerified ? new Date().toISOString().split('T')[0] : undefined,
        verifiedBy: residencyVerified ? 'Registrar Office' : undefined,
      },
    ];

    const newStudent = enrollStudent({
      firstName,
      lastName,
      preferredName: preferredName || undefined,
      dob,
      gender,
      gradeLevel,
      schoolLevel,
      homeroom,
      counselor,
      ssid: ssid.trim(),
      localId,
      enrollmentStatus: 'Active',
      enrollmentDate: new Date().toISOString().split('T')[0],
      guardians: [
        {
          id: `g-${Date.now()}`,
          name: guardianName,
          relationship: guardianRelation,
          phone: guardianPhone || '(415) 555-0100',
          email: guardianEmail || 'guardian@example.com',
          isPrimary: true,
          canPickup: true,
          address: `${street}, ${city}, ${state} ${zip}`,
        },
      ],
      emergencyContacts: emergName ? [{ name: emergName, relation: 'Emergency Contact', phone: emergPhone }] : [],
      address: {
        street: street || '100 Main St',
        city,
        state,
        zip,
      },
      programs: {
        iep,
        section504,
        ell,
        primaryLanguage,
        freeReducedLunch,
        giftedTalented,
      },
      documents: docs,
      medicalNotes: medicalNotes || undefined,
    });

    setSelectedStudentId(newStudent.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              New Student Enrollment
            </h2>
            <p className="text-xs text-slate-500">
              Complete registration, state identifier assignment, and intake verification
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Step Tabs */}
        <div className="grid grid-cols-4 border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-600">
          {[
            { num: 1, title: 'Demographics' },
            { num: 2, title: 'Guardians' },
            { num: 3, title: 'Programs' },
            { num: 4, title: 'Documents' },
          ].map((s) => (
            <button
              key={s.num}
              type="button"
              onClick={() => setStep(s.num as any)}
              className={`py-2.5 px-3 text-center border-b-2 transition-colors cursor-pointer ${
                step === s.num
                  ? 'border-indigo-600 text-indigo-700 font-semibold bg-white'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              {s.num}. {s.title}
            </button>
          ))}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 max-h-[65vh] overflow-y-auto space-y-4">
          {step === 1 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700">First Name *</label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="e.g. Liam"
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="e.g. Chen"
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700">Date of Birth</label>
                  <input
                    type="date"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">Gender</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                    <option value="Non-Binary">Non-Binary</option>
                    <option value="Prefer not to say">Prefer not to say</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">Grade Level</label>
                  <select
                    value={gradeLevel}
                    onChange={(e) => {
                      const g = e.target.value;
                      setGradeLevel(g);
                      if (g === 'K' || parseInt(g) <= 5) setSchoolLevel('Elementary');
                      else if (parseInt(g) <= 8) setSchoolLevel('Middle');
                      else setSchoolLevel('High');
                    }}
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="K">Kindergarten</option>
                    <option value="1">Grade 1</option>
                    <option value="2">Grade 2</option>
                    <option value="3">Grade 3</option>
                    <option value="4">Grade 4</option>
                    <option value="5">Grade 5</option>
                    <option value="6">Grade 6</option>
                    <option value="7">Grade 7</option>
                    <option value="8">Grade 8</option>
                    <option value="9">Grade 9 (Freshman)</option>
                    <option value="10">Grade 10 (Sophomore)</option>
                    <option value="11">Grade 11 (Junior)</option>
                    <option value="12">Grade 12 (Senior)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    State Student Identifier (SSID) *
                  </label>
                  <div className="mt-1 flex gap-2">
                    <input
                      type="text"
                      required
                      value={ssid}
                      onChange={(e) => setSsid(e.target.value)}
                      placeholder="e.g. CA-904128991"
                      className="w-full px-3 py-1.5 text-xs font-mono border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setSsid('CA-904128' + Math.floor(100 + Math.random() * 899))}
                      className="px-2 py-1 text-[11px] text-slate-600 bg-slate-100 hover:bg-slate-200 rounded border border-slate-300 whitespace-nowrap cursor-pointer"
                    >
                      Gen ID
                    </button>
                  </div>
                  <p className="mt-1 text-[10px] text-slate-400">
                    Required for state apportionment and CALPADS/Ed-Fi reporting
                  </p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">Local District ID</label>
                  <input
                    type="text"
                    value={localId}
                    onChange={(e) => setLocalId(e.target.value)}
                    className="mt-1 w-full px-3 py-1.5 text-xs font-mono border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700">Homeroom Assignment</label>
                  <input
                    type="text"
                    value={homeroom}
                    onChange={(e) => setHomeroom(e.target.value)}
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">Assigned Counselor</label>
                  <input
                    type="text"
                    value={counselor}
                    onChange={(e) => setCounselor(e.target.value)}
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700">Primary Guardian Name *</label>
                  <input
                    type="text"
                    required
                    value={guardianName}
                    onChange={(e) => setGuardianName(e.target.value)}
                    placeholder="e.g. Maria Chen"
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">Relationship</label>
                  <select
                    value={guardianRelation}
                    onChange={(e) => setGuardianRelation(e.target.value as any)}
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="Mother">Mother</option>
                    <option value="Father">Father</option>
                    <option value="Legal Guardian">Legal Guardian</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700">Primary Phone</label>
                  <input
                    type="tel"
                    value={guardianPhone}
                    onChange={(e) => setGuardianPhone(e.target.value)}
                    placeholder="(415) 555-0182"
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">Primary Email</label>
                  <input
                    type="email"
                    value={guardianEmail}
                    onChange={(e) => setGuardianEmail(e.target.value)}
                    placeholder="m.chen@example.com"
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700">Residential Street Address</label>
                <input
                  type="text"
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  placeholder="e.g. 524 Oakridge Blvd"
                  className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700">City</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">State</label>
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">Zip Code</label>
                  <input
                    type="text"
                    value={zip}
                    onChange={(e) => setZip(e.target.value)}
                    className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200">
                <p className="text-xs font-medium text-slate-700 mb-2">Emergency Contact</p>
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={emergName}
                    onChange={(e) => setEmergName(e.target.value)}
                    placeholder="Contact Name"
                    className="px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                  <input
                    type="tel"
                    value={emergPhone}
                    onChange={(e) => setEmergPhone(e.target.value)}
                    placeholder="Contact Phone"
                    className="px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700">Home Primary Language</label>
                <select
                  value={primaryLanguage}
                  onChange={(e) => {
                    const l = e.target.value;
                    setPrimaryLanguage(l);
                    if (l !== 'English') setEll(true);
                  }}
                  className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                >
                  <option value="English">English</option>
                  <option value="Spanish">Spanish</option>
                  <option value="Mandarin">Mandarin</option>
                  <option value="Vietnamese">Vietnamese</option>
                  <option value="Korean">Korean</option>
                  <option value="Tagalog">Tagalog</option>
                  <option value="Arabic">Arabic</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div className="space-y-2.5 pt-2">
                <label className="flex items-center gap-3 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={iep}
                    onChange={(e) => setIep(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-900">Individualized Education Program (IEP)</span>
                    <p className="text-[11px] text-slate-500">Active special education services plan</p>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={section504}
                    onChange={(e) => setSection504(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-900">Section 504 Accommodation Plan</span>
                    <p className="text-[11px] text-slate-500">Medical or learning environmental accommodation</p>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={ell}
                    onChange={(e) => setEll(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-900">English Language Learner (ELL / ML)</span>
                    <p className="text-[11px] text-slate-500">Requires language acquisition support and ELPAC tracking</p>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={freeReducedLunch}
                    onChange={(e) => setFreeReducedLunch(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-900">National School Lunch Program (Free/Reduced)</span>
                    <p className="text-[11px] text-slate-500">Title I compensatory education demographic indicator</p>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={giftedTalented}
                    onChange={(e) => setGiftedTalented(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-900">Gifted & Talented Education (GATE)</span>
                    <p className="text-[11px] text-slate-500">Identified for accelerated or honors coursework</p>
                  </div>
                </label>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                Check off verified physical or digital documents examined during enrollment intake:
              </p>

              <div className="space-y-3">
                <label className="flex items-start gap-3 p-3 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={birthCertVerified}
                    onChange={(e) => setBirthCertVerified(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-indigo-600 rounded border-slate-300"
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-900">Certified Birth Certificate / Age Verification</span>
                    <p className="text-[11px] text-slate-500">Validates date of birth and legal full name</p>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-3 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={immunizationVerified}
                    onChange={(e) => setImmunizationVerified(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-indigo-600 rounded border-slate-300"
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-900">Official Immunization Records (Polio, DTaP, MMR, Varicella)</span>
                    <p className="text-[11px] text-slate-500">Mandated for state health clearance</p>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-3 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={residencyVerified}
                    onChange={(e) => setResidencyVerified(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-indigo-600 rounded border-slate-300"
                  />
                  <div>
                    <span className="text-xs font-semibold text-slate-900">Proof of District Residency (Utility Bill or Lease Agreement)</span>
                    <p className="text-[11px] text-slate-500">Validates attendance zone boundaries</p>
                  </div>
                </label>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700">Health / Medical Clinic Notes</label>
                <textarea
                  rows={2}
                  value={medicalNotes}
                  onChange={(e) => setMedicalNotes(e.target.value)}
                  placeholder="e.g. Allergies, rescue medication, dietary requirements..."
                  className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* Navigation Footers */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep((s) => (s - 1) as any)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
              >
                Previous
              </button>
            ) : (
              <div />
            )}

            {step < 4 ? (
              <button
                type="button"
                onClick={() => setStep((s) => (s + 1) as any)}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-md transition-colors cursor-pointer"
              >
                Continue to Step {step + 1}
              </button>
            ) : (
              <button
                type="submit"
                className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-xs transition-colors cursor-pointer"
              >
                Complete Enrollment
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
