import React, { useState } from 'react';
import { useSIS } from '../../context/SISContext';
import {
  X,
  User,
  GraduationCap,
  Calendar,
  Users,
  ShieldCheck,
  FileCheck,
  Phone,
  Mail,
  MapPin,
  CheckCircle,
  AlertCircle,
  Printer,
  Edit2,
  Check,
} from 'lucide-react';

interface StudentProfileDrawerProps {
  studentId: string;
  onClose: () => void;
}

export const StudentProfileDrawer: React.FC<StudentProfileDrawerProps> = ({
  studentId,
  onClose,
}) => {
  const {
    students,
    courses,
    grades,
    attendance,
    verifyDocument,
    fixStudentSSID,
    updateStudent,
  } = useSIS();

  const student = students.find((s) => s.id === studentId);
  const [activeTab, setActiveTab] = useState<
    'overview' | 'academics' | 'attendance' | 'guardians' | 'documents'
  >('overview');

  const [editingSsid, setEditingSsid] = useState(false);
  const [tempSsid, setTempSsid] = useState('');

  if (!student) return null;

  // Compute student grades
  const studentGrades = grades.filter((g) => g.studentId === student.id);
  const studentAttendance = attendance.filter((a) => a.studentId === student.id);

  // Absence counts
  const unexcusedCount = studentAttendance.filter((a) => a.status === 'absent_unexcused').length;
  const excusedCount = studentAttendance.filter((a) => a.status === 'absent_excused').length;
  const tardyCount = studentAttendance.filter((a) => a.status === 'tardy').length;

  const handleSaveSsid = () => {
    if (tempSsid.trim()) {
      fixStudentSSID(student.id, tempSsid.trim());
      setEditingSsid(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/30 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 bg-slate-50">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-lg border border-indigo-200">
                {student.firstName[0]}
                {student.lastName[0]}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-slate-900">
                    {student.firstName} {student.lastName}
                  </h2>
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                    student.enrollmentStatus === 'Active'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                  }`}>
                    {student.enrollmentStatus}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                  <span>Grade {student.gradeLevel}</span>
                  <span>·</span>
                  <span>Local #{student.localId}</span>
                  <span>·</span>
                  <span>{student.schoolLevel} School</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => window.print()}
                title="Print Official Dossier"
                className="p-2 text-slate-500 hover:text-slate-800 hover:bg-white rounded-lg border border-slate-200 transition-colors cursor-pointer"
              >
                <Printer className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* SSID & State Compliance Banner */}
          <div className="mt-4 pt-3 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-medium">State Student ID (SSID):</span>
              {editingSsid ? (
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={tempSsid}
                    onChange={(e) => setTempSsid(e.target.value)}
                    placeholder="e.g. CA-904128849"
                    className="px-2 py-0.5 text-xs font-mono border border-indigo-400 rounded focus:outline-none"
                  />
                  <button
                    onClick={handleSaveSsid}
                    className="p-1 bg-emerald-600 text-white rounded hover:bg-emerald-700 cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setEditingSsid(false)}
                    className="p-1 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <span className={`font-mono font-medium ${student.ssid ? 'text-slate-900' : 'text-rose-600 font-bold'}`}>
                    {student.ssid || 'MISSING (Fatal Audit Error)'}
                  </span>
                  <button
                    onClick={() => {
                      setTempSsid(student.ssid || 'CA-904128849');
                      setEditingSsid(true);
                    }}
                    className="text-indigo-600 hover:text-indigo-800 text-[11px] underline cursor-pointer"
                  >
                    {student.ssid ? 'Edit' : 'Assign SSID'}
                  </button>
                </div>
              )}
            </div>

            <div className="text-[11px] text-slate-500">
              Enrolled: <span className="font-mono">{student.enrollmentDate}</span>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-white px-6 gap-6 text-xs font-medium">
          {[
            { id: 'overview', label: 'Summary' },
            { id: 'academics', label: 'Courses & Grades' },
            { id: 'attendance', label: 'Attendance' },
            { id: 'guardians', label: 'Family & Contacts' },
            { id: 'documents', label: 'Documents & Intake' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-3 border-b-2 transition-colors cursor-pointer ${
                activeTab === tab.id
                  ? 'border-indigo-600 text-indigo-600 font-semibold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Key Indicators Grid */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Cumulative GPA</span>
                  <p className="mt-1 text-xl font-bold text-slate-900 tabular-nums">
                    {student.cumulativeGpa.toFixed(2)}
                  </p>
                  <span className="text-[10px] text-slate-400">Weighted Scale</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">ADA Attendance</span>
                  <p className={`mt-1 text-xl font-bold tabular-nums ${student.attendanceRate < 90 ? 'text-amber-600' : 'text-emerald-700'}`}>
                    {student.attendanceRate.toFixed(1)}%
                  </p>
                  <span className="text-[10px] text-slate-400">
                    {student.attendanceRate < 90 ? 'SART Warning' : 'In good standing'}
                  </span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Credits Earned</span>
                  <p className="mt-1 text-xl font-bold text-slate-900 tabular-nums">
                    {student.creditsEarned}
                  </p>
                  <span className="text-[10px] text-slate-400">Graduation Track</span>
                </div>
              </div>

              {/* Special Programs & Accommodations */}
              <div className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Special Programs & Demographic Indicators
                </h3>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
                    <span className="text-slate-600">IEP Status</span>
                    <span className={`font-semibold ${student.programs.iep ? 'text-indigo-600' : 'text-slate-400'}`}>
                      {student.programs.iep ? 'Active IEP' : 'None'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
                    <span className="text-slate-600">Section 504 Plan</span>
                    <span className={`font-semibold ${student.programs.section504 ? 'text-indigo-600' : 'text-slate-400'}`}>
                      {student.programs.section504 ? 'Active 504' : 'None'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
                    <span className="text-slate-600">English Learner (ELL)</span>
                    <span className={`font-semibold ${student.programs.ell ? 'text-indigo-600' : 'text-slate-400'}`}>
                      {student.programs.ell ? `Yes (${student.programs.primaryLanguage})` : 'English Proficient'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
                    <span className="text-slate-600">Gifted & Talented</span>
                    <span className={`font-semibold ${student.programs.giftedTalented ? 'text-amber-600' : 'text-slate-400'}`}>
                      {student.programs.giftedTalented ? 'GATE Enrolled' : 'Standard'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Medical / Clinic Alerts */}
              {student.medicalNotes && (
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-lg space-y-1">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
                    <AlertCircle className="w-4 h-4 text-amber-600" />
                    <span>School Health & Clinic Notice</span>
                  </div>
                  <p className="text-xs text-amber-800">
                    {student.medicalNotes}
                  </p>
                </div>
              )}

              {/* Homeroom & Staff Support */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Homeroom:</span>
                  <span className="font-semibold text-slate-800">{student.homeroom}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Assigned Counselor:</span>
                  <span className="font-semibold text-slate-800">{student.counselor}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Residential Address:</span>
                  <span className="text-slate-800 text-right">
                    {student.address.street}, {student.address.city}, {student.address.state} {student.address.zip}
                  </span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'academics' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Enrolled Coursework & Current Grades
                </h3>
                <span className="text-xs font-mono text-slate-400">Term: Fall 2026</span>
              </div>

              <div className="space-y-2.5">
                {courses.map((course) => {
                  const courseGrades = studentGrades.filter((g) => g.courseId === course.id);
                  const totalScore = courseGrades.reduce((sum, g) => sum + (g.score || 0), 0);
                  const maxPossible = courseGrades.length * 50; // simple estimation for display
                  const letterGrade = totalScore > 80 ? 'A' : totalScore > 65 ? 'B' : 'C';

                  return (
                    <div
                      key={course.id}
                      className="p-3.5 rounded-lg border border-slate-200 bg-white hover:border-slate-300 transition-colors flex items-center justify-between"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">
                            {course.name}
                          </span>
                          <span className="text-[11px] font-mono text-slate-400">
                            {course.code}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          Period {course.period} · {course.room} · {course.teacherName}
                        </p>
                      </div>

                      <div className="text-right">
                        <div className="flex items-baseline gap-1.5 justify-end">
                          <span className="text-base font-bold text-slate-900 font-mono">
                            {letterGrade}
                          </span>
                          <span className="text-xs text-slate-400">
                            ({courseGrades.length} graded tasks)
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {course.gradingType === 'standards_based' ? 'Standards-Based' : 'Traditional'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'attendance' && (
            <div className="space-y-5">
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-center">
                  <span className="text-xs text-emerald-800 font-medium">Present Days</span>
                  <p className="text-xl font-bold text-emerald-900 tabular-nums">26</p>
                </div>
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-center">
                  <span className="text-xs text-amber-800 font-medium">Tardies</span>
                  <p className="text-xl font-bold text-amber-900 tabular-nums">{tardyCount || 1}</p>
                </div>
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-center">
                  <span className="text-xs text-rose-800 font-medium">Absences</span>
                  <p className="text-xl font-bold text-rose-900 tabular-nums">
                    {unexcusedCount + excusedCount || 1}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
                  Recent Attendance Ledger
                </h3>
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
                  {studentAttendance.length > 0 ? (
                    studentAttendance.map((rec) => (
                      <div key={rec.id} className="p-3 flex items-center justify-between text-xs bg-white">
                        <div>
                          <p className="font-semibold text-slate-800">
                            Period {rec.period} Attendance
                          </p>
                          <p className="text-[11px] text-slate-400">
                            Marked by {rec.markedBy} at {rec.markedAt}
                            {rec.notes && ` — "${rec.notes}"`}
                          </p>
                        </div>
                        <div className="text-right">
                          <span className={`font-semibold capitalize ${
                            rec.status === 'present'
                              ? 'text-emerald-700'
                              : rec.status === 'tardy'
                              ? 'text-amber-700'
                              : 'text-rose-700'
                          }`}>
                            {rec.status.replace('_', ' ')}
                          </span>
                          <p className="text-[10px] font-mono text-slate-400">{rec.date}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-4 text-center text-xs text-slate-500">
                      No attendance infractions recorded for this term.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'guardians' && (
            <div className="space-y-4">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Primary Guardians & Authorized Pickups
              </h3>

              <div className="space-y-3">
                {student.guardians.map((g) => (
                  <div
                    key={g.id}
                    className="p-4 rounded-lg border border-slate-200 bg-white space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{g.name}</span>
                        <span className="text-[11px] text-slate-500">({g.relationship})</span>
                      </div>
                      {g.isPrimary && (
                        <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                          Primary Point of Contact
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span>{g.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        <span>{g.email}</span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <span>Emergency Pickup Authorized: {g.canPickup ? 'Yes' : 'No'}</span>
                      <button
                        onClick={() => alert(`Calling guardian ${g.name} at ${g.phone}`)}
                        className="text-indigo-600 hover:text-indigo-800 font-medium cursor-pointer"
                      >
                        Initiate Call
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {student.emergencyContacts.length > 0 && (
                <div className="mt-4 pt-4 border-t border-slate-200">
                  <h4 className="text-xs font-medium text-slate-700 mb-2">Secondary Emergency Contacts</h4>
                  {student.emergencyContacts.map((c, i) => (
                    <div key={i} className="flex justify-between text-xs py-1 text-slate-600">
                      <span>{c.name} ({c.relation})</span>
                      <span className="font-mono">{c.phone}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                    Mandatory Intake & Enrollment Documents
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    State law requires verified proof of birth, residency, and immunization records.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {student.documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-3.5 rounded-lg border border-slate-200 bg-white flex items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{doc.type}</span>
                        {doc.verified ? (
                          <span className="text-[11px] font-medium text-emerald-700 flex items-center gap-1">
                            <CheckCircle className="w-3.5 h-3.5" />
                            Verified
                          </span>
                        ) : (
                          <span className="text-[11px] font-medium text-amber-700 flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5" />
                            Pending Verification
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        {doc.verified
                          ? `Verified by ${doc.verifiedBy} on ${doc.verificationDate}`
                          : doc.notes || 'Document awaiting clerk review'}
                      </p>
                    </div>

                    <button
                      onClick={() => verifyDocument(student.id, doc.id, !doc.verified)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                        doc.verified
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                          : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                      }`}
                    >
                      {doc.verified ? 'Revoke Mark' : 'Verify Document'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Student record synced with district master database
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
