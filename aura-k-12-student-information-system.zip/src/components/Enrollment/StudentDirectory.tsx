import React, { useState, useMemo } from 'react';
import { useSIS } from '../../context/SISContext';
import {
  Search,
  Filter,
  UserPlus,
  SlidersHorizontal,
  ChevronDown,
  ArrowUpDown,
  FileCheck,
  AlertTriangle,
  Eye,
  Download,
} from 'lucide-react';
import { Student } from '../../types/sis';
import { NewEnrollmentModal } from './NewEnrollmentModal';
import { StudentProfileDrawer } from './StudentProfileDrawer';

export const StudentDirectory: React.FC = () => {
  const {
    students,
    selectedStudentId,
    setSelectedStudentId,
  } = useSIS();

  const [search, setSearch] = useState('');
  const [schoolLevelFilter, setSchoolLevelFilter] = useState<'All' | 'High' | 'Middle' | 'Elementary'>('All');
  const [gradeFilter, setGradeFilter] = useState<string>('All');
  const [programFilter, setProgramFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [enrollModalOpen, setEnrollModalOpen] = useState(false);

  // Sorting
  const [sortField, setSortField] = useState<'lastName' | 'gradeLevel' | 'cumulativeGpa' | 'attendanceRate'>('lastName');
  const [sortAsc, setSortAsc] = useState(true);

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      // Search text
      if (search.trim()) {
        const q = search.toLowerCase();
        const fullName = `${student.firstName} ${student.lastName}`.toLowerCase();
        const matchesName = fullName.includes(q);
        const matchesLocal = student.localId.toLowerCase().includes(q);
        const matchesSsid = student.ssid.toLowerCase().includes(q);
        if (!matchesName && !matchesLocal && !matchesSsid) return false;
      }

      // School Level
      if (schoolLevelFilter !== 'All' && student.schoolLevel !== schoolLevelFilter) {
        return false;
      }

      // Grade
      if (gradeFilter !== 'All' && student.gradeLevel !== gradeFilter) {
        return false;
      }

      // Status
      if (statusFilter !== 'All' && student.enrollmentStatus !== statusFilter) {
        return false;
      }

      // Programs
      if (programFilter === 'iep' && !student.programs.iep) return false;
      if (programFilter === '504' && !student.programs.section504) return false;
      if (programFilter === 'ell' && !student.programs.ell) return false;
      if (programFilter === 'gifted' && !student.programs.giftedTalented) return false;
      if (programFilter === 'frl' && !student.programs.freeReducedLunch) return false;

      return true;
    }).sort((a, b) => {
      let valA: any = a[sortField];
      let valB: any = b[sortField];
      if (sortField === 'gradeLevel') {
        valA = a.gradeLevel === 'K' ? 0 : parseInt(a.gradeLevel);
        valB = b.gradeLevel === 'K' ? 0 : parseInt(b.gradeLevel);
      }
      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });
  }, [students, search, schoolLevelFilter, gradeFilter, programFilter, statusFilter, sortField, sortAsc]);

  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const handleExportCsv = () => {
    const headers = ['Local ID', 'SSID', 'First Name', 'Last Name', 'Grade', 'School Level', 'GPA', 'Attendance %', 'Status'];
    const rows = filteredStudents.map((s) => [
      s.localId,
      s.ssid || 'MISSING',
      s.firstName,
      s.lastName,
      s.gradeLevel,
      s.schoolLevel,
      s.cumulativeGpa.toFixed(2),
      s.attendanceRate.toFixed(1),
      s.enrollmentStatus,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `student_directory_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Student Roster & Enrollment Directory
          </h1>
          <p className="text-xs text-slate-500">
            {students.length} Total Enrolled Students · Oakridge Unified School District
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setEnrollModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Enroll Student</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by student name, local ID, or SSID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-md focus:border-indigo-500 focus:outline-none placeholder:text-slate-400"
            />
          </div>

          {/* Segmented School Level Buttons */}
          <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs self-stretch sm:self-auto">
            {(['All', 'High', 'Middle', 'Elementary'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setSchoolLevelFilter(lvl)}
                className={`flex-1 sm:flex-initial px-3 py-1 font-medium rounded-md transition-colors cursor-pointer ${
                  schoolLevelFilter === lvl
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {lvl === 'All' ? 'All Schools' : `${lvl} School`}
              </button>
            ))}
          </div>

          {/* Grade Dropdown */}
          <select
            value={gradeFilter}
            onChange={(e) => setGradeFilter(e.target.value)}
            className="w-full sm:w-auto px-2.5 py-1.5 text-xs border border-slate-200 rounded-md text-slate-700 focus:border-indigo-500 focus:outline-none"
          >
            <option value="All">All Grades</option>
            <option value="K">Kindergarten</option>
            <option value="4">Grade 4</option>
            <option value="7">Grade 7</option>
            <option value="10">Grade 10</option>
            <option value="11">Grade 11</option>
            <option value="12">Grade 12</option>
          </select>

          {/* Programs Filter */}
          <select
            value={programFilter}
            onChange={(e) => setProgramFilter(e.target.value)}
            className="w-full sm:w-auto px-2.5 py-1.5 text-xs border border-slate-200 rounded-md text-slate-700 focus:border-indigo-500 focus:outline-none"
          >
            <option value="All">All Special Programs</option>
            <option value="iep">Active IEP</option>
            <option value="504">Section 504 Plan</option>
            <option value="ell">English Learner (ELL)</option>
            <option value="gifted">Gifted & Talented (GATE)</option>
            <option value="frl">Free/Reduced Lunch (FRL)</option>
          </select>
        </div>
      </div>

      {/* High-Density Data Grid (SaaS Dashboard Standard) */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                <th
                  onClick={() => toggleSort('lastName')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-800"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Student / ID</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4">State Identifier (SSID)</th>
                <th
                  onClick={() => toggleSort('gradeLevel')}
                  className="py-3 px-3 cursor-pointer hover:text-slate-800"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Grade</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4">Homeroom & Counselor</th>
                <th className="py-3 px-4">Programs & Accommodations</th>
                <th
                  onClick={() => toggleSort('cumulativeGpa')}
                  className="py-3 px-3 text-right cursor-pointer hover:text-slate-800"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>GPA</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => toggleSort('attendanceRate')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-slate-800"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>ADA %</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4">Intake Verification</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length > 0 ? (
                filteredStudents.map((student) => {
                  const verifiedDocs = student.documents.filter((d) => d.verified).length;
                  const totalDocs = student.documents.length;
                  const isMissingSsid = !student.ssid;
                  const isChronic = student.attendanceRate < 90.0;

                  return (
                    <tr
                      key={student.id}
                      onClick={() => setSelectedStudentId(student.id)}
                      className="hover:bg-indigo-50/40 transition-colors cursor-pointer group"
                    >
                      {/* Name & Local ID */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-slate-700">
                            {student.firstName[0]}
                            {student.lastName[0]}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors">
                              {student.lastName}, {student.firstName}
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              #{student.localId} · {student.gender}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* State Student ID (SSID) */}
                      <td className="py-3 px-4">
                        {isMissingSsid ? (
                          <div className="flex items-center gap-1.5 text-rose-600 font-medium">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span className="font-mono text-[11px]">Unassigned</span>
                          </div>
                        ) : (
                          <span className="font-mono text-slate-700 text-xs">
                            {student.ssid}
                          </span>
                        )}
                      </td>

                      {/* Grade */}
                      <td className="py-3 px-3">
                        <span className="font-mono font-medium text-slate-800">
                          {student.gradeLevel === 'K' ? 'Kinder' : `Gr ${student.gradeLevel}`}
                        </span>
                      </td>

                      {/* Homeroom */}
                      <td className="py-3 px-4">
                        <div className="text-slate-800 font-medium">{student.homeroom}</div>
                        <div className="text-[11px] text-slate-400">{student.counselor}</div>
                      </td>

                      {/* Special Programs (Unboxed text metadata with dots) */}
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-600">
                          {student.programs.iep && <span className="text-indigo-700 font-medium">IEP</span>}
                          {student.programs.iep && student.programs.section504 && <span>·</span>}
                          {student.programs.section504 && <span className="text-sky-700 font-medium">504</span>}
                          {(student.programs.iep || student.programs.section504) && student.programs.ell && <span>·</span>}
                          {student.programs.ell && <span className="text-amber-700 font-medium">ELL ({student.programs.primaryLanguage})</span>}
                          {student.programs.giftedTalented && (
                            <>
                              <span>·</span>
                              <span className="text-emerald-700 font-medium">GATE</span>
                            </>
                          )}
                          {!student.programs.iep && !student.programs.section504 && !student.programs.ell && !student.programs.giftedTalented && (
                            <span className="text-slate-400">General Education</span>
                          )}
                        </div>
                      </td>

                      {/* Cumulative GPA */}
                      <td className="py-3 px-3 text-right tabular-nums font-mono font-bold text-slate-900">
                        {student.cumulativeGpa.toFixed(2)}
                      </td>

                      {/* ADA % */}
                      <td className="py-3 px-4 text-right tabular-nums font-mono">
                        <span className={`font-bold ${isChronic ? 'text-amber-600' : 'text-slate-800'}`}>
                          {student.attendanceRate.toFixed(1)}%
                        </span>
                      </td>

                      {/* Verification Status */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 text-[11px]">
                          <span className={`font-mono ${verifiedDocs === totalDocs ? 'text-emerald-700' : 'text-amber-700 font-medium'}`}>
                            {verifiedDocs}/{totalDocs} Verified
                          </span>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setSelectedStudentId(student.id)}
                          className="px-2.5 py-1 text-xs text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded font-medium transition-colors cursor-pointer"
                        >
                          View 360°
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-xs text-slate-500">
                    No students match the selected filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Summary */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>
            Showing <strong className="text-slate-700 font-mono">{filteredStudents.length}</strong> of{' '}
            <strong className="text-slate-700 font-mono">{students.length}</strong> students
          </span>
          <span className="font-mono">
            District Apportionment Roster Active
          </span>
        </div>
      </div>

      {/* Modals */}
      <NewEnrollmentModal
        isOpen={enrollModalOpen}
        onClose={() => setEnrollModalOpen(false)}
      />

      {selectedStudentId && (
        <StudentProfileDrawer
          studentId={selectedStudentId}
          onClose={() => setSelectedStudentId(null)}
        />
      )}
    </div>
  );
};
