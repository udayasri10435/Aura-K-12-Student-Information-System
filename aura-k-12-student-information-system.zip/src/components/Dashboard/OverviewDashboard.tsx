import React from 'react';
import { useSIS } from '../../context/SISContext';
import {
  Users,
  CalendarCheck,
  Award,
  AlertTriangle,
  FileText,
  UserPlus,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  TrendingUp,
} from 'lucide-react';

export const OverviewDashboard: React.FC = () => {
  const {
    students,
    courses,
    attendance,
    absenceNotes,
    validationRules,
    setActiveModule,
    setSelectedStudentId,
    updateAbsenceNoteStatus,
    setRole,
  } = useSIS();

  // Metrics
  const totalStudents = students.length;
  const activeStudents = students.filter((s) => s.enrollmentStatus === 'Active').length;
  const pendingReviewStudents = students.filter((s) => s.enrollmentStatus === 'Pending Review').length;

  // ADA Calculation
  const todayRecords = attendance.filter((a) => a.date === '2026-09-29');
  const presentCount = todayRecords.filter((a) => a.status === 'present' || a.status === 'tardy').length;
  const todayADA = todayRecords.length > 0 ? ((presentCount / todayRecords.length) * 100).toFixed(1) : '96.2';

  // Chronic Absenteeism (<90%)
  const chronicallyAbsent = students.filter((s) => s.attendanceRate < 90.0);

  // State audit fatal errors
  const fatalErrors = validationRules.filter((r) => r.severity === 'Fatal Error');
  const totalFatalAffected = fatalErrors.reduce((sum, r) => sum + r.affectedCount, 0);

  // Pending absence notes
  const pendingNotes = absenceNotes.filter((n) => n.status === 'Pending');

  return (
    <div className="space-y-6">
      {/* Top Banner / Hero with District Summary */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-indigo-600">
              <span>Fall Semester 2026</span>
              <span aria-hidden="true">·</span>
              <span>Week 6 of 18</span>
              <span aria-hidden="true">·</span>
              <span>Oakridge Unified District</span>
            </div>
            <h1 className="mt-1 text-2xl font-bold tracking-tight text-slate-900">
              District Operational Intelligence
            </h1>
            <p className="mt-1 text-sm text-slate-500 max-w-2xl">
              Real-time student information, live period attendance, weighted gradebooks, and automated state compliance reporting.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveModule('enrollment')}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>Enroll Student</span>
            </button>
            <button
              onClick={() => setActiveModule('state_reporting')}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <FileText className="w-4 h-4 text-slate-500" />
              <span>Audit Compliance</span>
            </button>
          </div>
        </div>

        {/* 4 Core Stat Tiles */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Tile 1: Total Enrolled */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Total Enrolled</span>
              <Users className="w-4 h-4 text-slate-400" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-bold tracking-tight text-slate-900 tabular-nums">
                {activeStudents}
              </span>
              <span className="text-xs text-slate-500 font-normal">
                active · {pendingReviewStudents} in review
              </span>
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <span>High: 7</span>
              <span>·</span>
              <span>Middle: 1</span>
              <span>·</span>
              <span>Elem: 1</span>
            </div>
          </div>

          {/* Tile 2: Today's ADA */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Average Daily Attendance</span>
              <CalendarCheck className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-bold tracking-tight text-emerald-700 tabular-nums">
                {todayADA}%
              </span>
              <span className="text-xs text-emerald-700 font-medium flex items-center gap-0.5">
                <TrendingUp className="w-3 h-3" />
                Target &ge; 95%
              </span>
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              State apportionment funding secure
            </div>
          </div>

          {/* Tile 3: Chronic Absenteeism */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Chronic Absenteeism Risk</span>
              <AlertTriangle className="w-4 h-4 text-amber-500" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-bold tracking-tight text-amber-700 tabular-nums">
                {chronicallyAbsent.length}
              </span>
              <span className="text-xs text-amber-700 font-medium">
                {((chronicallyAbsent.length / totalStudents) * 100).toFixed(1)}% of cohort
              </span>
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              Under 90.0% statutory attendance
            </div>
          </div>

          {/* Tile 4: State Compliance Health */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">State Reporting Health</span>
              {totalFatalAffected > 0 ? (
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              )}
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className={`text-2xl font-bold tracking-tight tabular-nums ${totalFatalAffected > 0 ? 'text-amber-700' : 'text-slate-900'}`}>
                {totalFatalAffected > 0 ? `${totalFatalAffected} Flags` : '100% Ready'}
              </span>
              <span className="text-xs text-slate-500 font-normal">
                CALPADS / Ed-Fi
              </span>
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              {totalFatalAffected > 0 ? 'Action required before census' : 'Zero validation blocks'}
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Pending Tasks, Recent Requests, and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Critical Interventions & Roster Highlights */}
        <div className="lg:col-span-2 space-y-6">
          {/* Compliance & Verification Action Center */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <h2 className="text-sm font-semibold text-slate-900">
                  Critical Compliance & Verification Queue
                </h2>
              </div>
              <button
                onClick={() => setActiveModule('state_reporting')}
                className="text-xs font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1 cursor-pointer"
              >
                <span>View Full Audit</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              {validationRules.map((rule) => (
                <div
                  key={rule.id}
                  className="p-3 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors flex items-start justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs">
                      <span className={`font-semibold ${
                        rule.severity === 'Fatal Error' ? 'text-rose-600' : 'text-amber-600'
                      }`}>
                        {rule.ruleCode}
                      </span>
                      <span className="text-slate-300">·</span>
                      <span className="text-slate-500 font-medium">{rule.category}</span>
                      <span className="text-slate-300">·</span>
                      <span className="text-slate-600 tabular-nums">
                        {rule.affectedCount} student{rule.affectedCount > 1 ? 's' : ''} affected
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 font-normal">
                      {rule.description}
                    </p>
                    <p className="text-[11px] text-slate-500 italic">
                      Recommendation: {rule.recommendation}
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      if (rule.affectedStudentIds[0]) {
                        setSelectedStudentId(rule.affectedStudentIds[0]);
                        setActiveModule('enrollment');
                      } else {
                        setActiveModule('state_reporting');
                      }
                    }}
                    className="shrink-0 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md transition-colors cursor-pointer"
                  >
                    Resolve
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Chronic Absenteeism Monitor */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-slate-600" />
                <h2 className="text-sm font-semibold text-slate-900">
                  Early Attendance Warning Watchlist
                </h2>
              </div>
              <button
                onClick={() => setActiveModule('attendance')}
                className="text-xs font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1 cursor-pointer"
              >
                <span>Attendance Grid</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-3 divide-y divide-slate-100">
              {students
                .slice()
                .sort((a, b) => a.attendanceRate - b.attendanceRate)
                .slice(0, 4)
                .map((student) => {
                  const isChronic = student.attendanceRate < 90.0;
                  return (
                    <div
                      key={student.id}
                      className="py-3 flex items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-semibold text-slate-700">
                          {student.firstName[0]}
                          {student.lastName[0]}
                        </div>
                        <div>
                          <p className="text-xs font-medium text-slate-900">
                            {student.firstName} {student.lastName}
                          </p>
                          <p className="text-[11px] text-slate-500">
                            Grade {student.gradeLevel} · {student.homeroom} · ID #{student.localId}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <p className={`text-xs font-bold tabular-nums ${isChronic ? 'text-amber-700' : 'text-slate-800'}`}>
                            {student.attendanceRate.toFixed(1)}% ADA
                          </p>
                          <p className="text-[10px] text-slate-400">
                            {isChronic ? 'Needs SART Review' : 'Good standing'}
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            setSelectedStudentId(student.id);
                            setActiveModule('enrollment');
                          }}
                          className="px-2 py-1 text-xs text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded cursor-pointer"
                        >
                          Profile
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Parent Absence Queue & Fast Tools */}
        <div className="space-y-6">
          {/* Parent Absence Notes Queue */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-600" />
                <h2 className="text-sm font-semibold text-slate-900">
                  Parent Absence Notes
                </h2>
              </div>
              <span className="text-xs font-mono text-slate-500">
                {pendingNotes.length} pending
              </span>
            </div>

            <div className="mt-3 space-y-3">
              {absenceNotes.slice(0, 3).map((note) => {
                const stu = students.find((s) => s.id === note.studentId);
                return (
                  <div
                    key={note.id}
                    className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold text-slate-900">
                        {stu?.firstName} {stu?.lastName}
                      </p>
                      <span className={`text-[10px] font-medium px-2 py-0.5 rounded ${
                        note.status === 'Approved'
                          ? 'bg-emerald-50 text-emerald-700'
                          : note.status === 'Declined'
                          ? 'bg-rose-50 text-rose-700'
                          : 'bg-amber-50 text-amber-700'
                      }`}>
                        {note.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600">
                      <span className="font-medium text-slate-800">{note.reason}:</span> {note.explanation}
                    </p>

                    <div className="text-[11px] text-slate-400 flex items-center justify-between">
                      <span>Submitted by {note.guardianName}</span>
                      <span className="font-mono">{note.startDate}</span>
                    </div>

                    {note.status === 'Pending' && (
                      <div className="pt-2 flex items-center gap-2 border-t border-slate-200">
                        <button
                          onClick={() => updateAbsenceNoteStatus(note.id, 'Approved', 'Attendance Admin')}
                          className="flex-1 py-1 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded transition-colors cursor-pointer"
                        >
                          Approve Excuse
                        </button>
                        <button
                          onClick={() => updateAbsenceNoteStatus(note.id, 'Declined', 'Attendance Admin')}
                          className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:bg-slate-200 rounded transition-colors cursor-pointer"
                        >
                          Decline
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Perspective Switcher Card */}
          <div className="bg-gradient-to-br from-indigo-50/60 to-slate-50 rounded-xl border border-indigo-100 p-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-900">
              Test Driving Personas
            </h3>
            <p className="mt-1 text-xs text-slate-600">
              Legacy SIS systems fail because they treat teachers, parents, and registrars identically. Test out Aura's role-optimized workflows:
            </p>

            <div className="mt-4 space-y-2">
              <button
                onClick={() => {
                  setRole('teacher');
                  setActiveModule('gradebook');
                }}
                className="w-full flex items-center justify-between p-2.5 bg-white hover:bg-indigo-50/70 border border-slate-200 rounded-lg text-left text-xs font-medium text-slate-800 transition-colors cursor-pointer"
              >
                <div>
                  <p className="font-semibold text-slate-900">Teacher Speed Gradebook</p>
                  <p className="text-[11px] text-slate-500">Inline scoring & standards mastery</p>
                </div>
                <ArrowUpRight className="w-4 h-4 text-indigo-600" />
              </button>

              <button
                onClick={() => {
                  setRole('parent');
                  setActiveModule('parent_portal');
                }}
                className="w-full flex items-center justify-between p-2.5 bg-white hover:bg-indigo-50/70 border border-slate-200 rounded-lg text-left text-xs font-medium text-slate-800 transition-colors cursor-pointer"
              >
                <div>
                  <p className="font-semibold text-slate-900">Parent Portal Experience</p>
                  <p className="text-[11px] text-slate-500">Sibling switching & verified excuse notes</p>
                </div>
                <ArrowUpRight className="w-4 h-4 text-indigo-600" />
              </button>

              <button
                onClick={() => {
                  setRole('admin');
                  setActiveModule('state_reporting');
                }}
                className="w-full flex items-center justify-between p-2.5 bg-white hover:bg-indigo-50/70 border border-slate-200 rounded-lg text-left text-xs font-medium text-slate-800 transition-colors cursor-pointer"
              >
                <div>
                  <p className="font-semibold text-slate-900">State Reporting & Ed-Fi</p>
                  <p className="text-[11px] text-slate-500">1-click error resolution & census extract</p>
                </div>
                <ArrowUpRight className="w-4 h-4 text-indigo-600" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
