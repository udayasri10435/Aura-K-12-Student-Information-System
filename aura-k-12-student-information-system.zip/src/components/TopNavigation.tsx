import React from 'react';
import { useSIS } from '../context/SISContext';
import { ActiveModule, UserRole } from '../types/sis';
import { Search, ShieldAlert, RotateCcw } from 'lucide-react';

export const TopNavigation: React.FC = () => {
  const {
    activeModule,
    setActiveModule,
    currentRole,
    setRole,
    setCommandPaletteOpen,
    validationRules,
    resetToDemoData,
  } = useSIS();

  const fatalErrorsCount = validationRules.filter((r) => r.severity === 'Fatal Error')
    .reduce((acc, r) => acc + r.affectedCount, 0);

  const navLinks: { id: ActiveModule; label: string }[] = [
    { id: 'dashboard', label: 'Overview' },
    { id: 'enrollment', label: 'Enrollment' },
    { id: 'gradebook', label: 'Gradebook' },
    { id: 'attendance', label: 'Attendance' },
    { id: 'parent_portal', label: 'Parent Portal' },
    { id: 'state_reporting', label: 'State Compliance' },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveModule('dashboard')}
              className="text-left group cursor-pointer focus:outline-none"
            >
              <span className="text-xl font-bold tracking-tight text-slate-900 group-hover:text-indigo-600 transition-colors">
                Aura SIS
              </span>
            </button>
            <span className="hidden md:inline text-xs text-slate-400 font-mono">
              v2.4 · Oakridge USD
            </span>
          </div>

          {/* Zone 2: 4–6 clean text navigation links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => {
              const isActive = activeModule === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => setActiveModule(link.id)}
                  className={`px-3 py-1.5 text-sm font-medium transition-colors relative cursor-pointer ${
                    isActive
                      ? 'text-indigo-600 font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span>{link.label}</span>
                  {link.id === 'state_reporting' && fatalErrorsCount > 0 && (
                    <span className="ml-1.5 inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-bold text-amber-800 bg-amber-100 rounded-sm">
                      {fatalErrorsCount}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-[-13px] left-3 right-3 h-0.5 bg-indigo-600 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Search, Role Switcher & Action controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick Command Trigger */}
            <button
              onClick={() => setCommandPaletteOpen(true)}
              className="flex items-center gap-2 px-2.5 py-1.5 text-xs text-slate-500 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md transition-colors cursor-pointer"
              title="Search students, courses, or compliance (Cmd+K)"
            >
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Jump to...</span>
              <kbd className="hidden sm:inline px-1 py-0.5 text-[10px] font-mono bg-white border border-slate-300 rounded text-slate-500">
                ⌘K
              </kbd>
            </button>

            {/* Role Switcher Button Group */}
            <div className="hidden sm:flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200">
              <button
                onClick={() => {
                  setRole('admin');
                  if (activeModule === 'parent_portal') setActiveModule('dashboard');
                }}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  currentRole === 'admin'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Admin
              </button>
              <button
                onClick={() => {
                  setRole('teacher');
                  setActiveModule('gradebook');
                }}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  currentRole === 'teacher'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Teacher
              </button>
              <button
                onClick={() => {
                  setRole('parent');
                  setActiveModule('parent_portal');
                }}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  currentRole === 'parent'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Parent
              </button>
            </div>

            {/* Demo Reset button */}
            <button
              onClick={() => {
                if (window.confirm('Reset all demo data back to default initial state?')) {
                  resetToDemoData();
                }
              }}
              title="Reset Demo Data"
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="lg:hidden flex items-center justify-between py-2 border-t border-slate-100 overflow-x-auto gap-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => setActiveModule(link.id)}
              className={`px-2.5 py-1 text-xs font-medium whitespace-nowrap cursor-pointer ${
                activeModule === link.id
                  ? 'text-indigo-600 font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
