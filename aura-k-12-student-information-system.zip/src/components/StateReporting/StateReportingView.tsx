import React, { useState } from 'react';
import { useSIS } from '../../context/SISContext';
import {
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Download,
  FileCheck,
  FileCode,
  RefreshCw,
  ArrowRight,
  Database,
  ExternalLink,
  Check,
} from 'lucide-react';
import { StateReportingStandard } from '../../types/sis';

export const StateReportingView: React.FC = () => {
  const {
    students,
    courses,
    attendance,
    validationRules,
    setSelectedStudentId,
    setActiveModule,
    fixStudentSSID,
  } = useSIS();

  const [standard, setStandard] = useState<StateReportingStandard>('CALPADS');
  const [extractType, setExtractType] = useState<'DEMO' | 'SENR' | 'SATS' | 'SPED'>('DEMO');
  const [auditRunning, setAuditRunning] = useState(false);
  const [lastAuditTimestamp, setLastAuditTimestamp] = useState('2026-09-29 08:15 AM');
  const [generatedPayload, setGeneratedPayload] = useState<string | null>(null);

  const fatalRules = validationRules.filter((r) => r.severity === 'Fatal Error');
  const warningRules = validationRules.filter((r) => r.severity === 'Warning');
  const totalFatalCount = fatalRules.reduce((sum, r) => sum + r.affectedCount, 0);

  const handleRunAudit = () => {
    setAuditRunning(true);
    setTimeout(() => {
      setAuditRunning(false);
      const now = new Date();
      setLastAuditTimestamp(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' Today');
    }, 600);
  };

  const handleGenerateExtract = () => {
    const timestamp = new Date().toISOString();
    let sampleData: any[] = [];

    if (extractType === 'DEMO') {
      sampleData = students.map((s) => ({
        StateStudentIdentifier: s.ssid || 'MISSING_FATAL_ERROR',
        LocalId: s.localId,
        LegalLastName: s.lastName,
        LegalFirstName: s.firstName,
        BirthDate: s.dob,
        GenderCode: s.gender[0],
        GradeLevelCode: s.gradeLevel,
        PrimaryLanguage: s.programs.primaryLanguage,
        EnglishLearnerStatus: s.programs.ell ? 'EL' : 'EO',
        SpecialEducationPlan: s.programs.iep ? 'IEP' : s.programs.section504 ? '504' : 'N',
        NationalSchoolLunchProgram: s.programs.freeReducedLunch ? 'Eligible' : 'Not_Eligible',
      }));
    } else if (extractType === 'SATS') {
      sampleData = students.map((s) => ({
        StateStudentIdentifier: s.ssid,
        LocalId: s.localId,
        GradeLevel: s.gradeLevel,
        InstructionalDaysEnrolled: 28,
        DaysAttended: 27,
        AverageDailyAttendanceRate: s.attendanceRate.toFixed(1),
        ChronicAbsenteeismStatus: s.attendanceRate < 90.0 ? 'CHRONIC_FLAG' : 'SATISFACTORY',
      }));
    } else if (extractType === 'SENR') {
      sampleData = students.map((s) => ({
        StateStudentIdentifier: s.ssid,
        SchoolCode: '0108420',
        SchoolName: 'Oakridge High School',
        EnrollmentStatusCode: 'Primary',
        EnrollmentStartDate: s.enrollmentDate,
        GradeLevel: s.gradeLevel,
      }));
    } else {
      sampleData = students.filter((s) => s.programs.iep || s.programs.section504).map((s) => ({
        StateStudentIdentifier: s.ssid,
        PlanType: s.programs.iep ? 'IDEA_Part_B_IEP' : 'Section_504',
        PrimaryDisability: 'Specific Learning Disability',
        ReviewDate: s.programs.iepReviewDate || '2026-11-15',
      }));
    }

    const jsonString = JSON.stringify(
      {
        ExtractionMetadata: {
          Specification: standard,
          ExtractType: extractType,
          DistrictCode: 'CA-0629402',
          DistrictName: 'Oakridge Unified School District',
          GeneratedAt: timestamp,
          TotalRecordCount: sampleData.length,
          ValidationStatus: totalFatalCount === 0 ? 'CERTIFIED_PASSED' : 'UNRESOLVED_FATAL_ERRORS',
        },
        Records: sampleData,
      },
      null,
      2
    );

    setGeneratedPayload(jsonString);
  };

  const handleDownloadExtract = () => {
    if (!generatedPayload) return;
    const blob = new Blob([generatedPayload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${standard}_${extractType}_EXTRACT_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleQuickFixSSID = (studentId: string) => {
    const generatedSSID = 'CA-904128' + Math.floor(100 + Math.random() * 899);
    fixStudentSSID(studentId, generatedSSID);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-indigo-600 font-semibold">
            <Database className="w-3.5 h-3.5" />
            <span>State Compliance & Statutory Reporting</span>
            <span>·</span>
            <span className="text-slate-500 font-normal">Fall Census 2026 Apportionment</span>
          </div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 mt-1">
            Automated State Audit & Ed-Fi Extract Engine
          </h1>
          <p className="text-xs text-slate-500 max-w-2xl">
            Continuous validation against official state department business rules (CALPADS, PEIMS, Ed-Fi, CRDC). Identifies fatal errors before state upload rejection.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Standard Picker */}
          <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs">
            {(['CALPADS', 'Ed-Fi', 'PEIMS', 'CRDC'] as const).map((std) => (
              <button
                key={std}
                onClick={() => {
                  setStandard(std);
                  setGeneratedPayload(null);
                }}
                className={`px-3 py-1 font-medium rounded-md transition-colors cursor-pointer ${
                  standard === std
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {std}
              </button>
            ))}
          </div>

          <button
            onClick={handleRunAudit}
            disabled={auditRunning}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-slate-500 ${auditRunning ? 'animate-spin' : ''}`} />
            <span>{auditRunning ? 'Auditing...' : 'Re-run Audit'}</span>
          </button>
        </div>
      </div>

      {/* Validation Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className={`p-4 rounded-xl border shadow-xs ${
          totalFatalCount > 0
            ? 'bg-rose-50/50 border-rose-200'
            : 'bg-emerald-50/50 border-emerald-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">Fatal Validation Errors</span>
            <ShieldAlert className={`w-4 h-4 ${totalFatalCount > 0 ? 'text-rose-600' : 'text-emerald-600'}`} />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className={`text-2xl font-bold font-mono ${totalFatalCount > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>
              {totalFatalCount}
            </span>
            <span className="text-xs text-slate-500">
              {totalFatalCount > 0 ? 'Blocks State Census Submission' : 'Zero Blocks Detected'}
            </span>
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            {totalFatalCount > 0 ? 'Must resolve before state extract file generation' : 'Audit clearance passed for state upload'}
          </p>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">State Compliance Warnings</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-amber-700">
              {warningRules.length}
            </span>
            <span className="text-xs text-slate-500">Requires Staff Review</span>
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Advisories on chronic absenteeism and IEP review milestones
          </p>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">Standard Specification</span>
            <span className="font-mono text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-700">
              Active Profile
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900">
              {standard}
            </span>
            <span className="text-xs text-slate-500">v4.0 Format</span>
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Last automated verification: <span className="font-mono">{lastAuditTimestamp}</span>
          </p>
        </div>
      </div>

      {/* Audit Errors Resolution Section */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              Live Audit Exceptions & 1-Click Resolution Triage
            </h2>
            <p className="text-xs text-slate-500">
              Resolve demographic discrepancies directly here without opening disjointed submenus
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {validationRules.length} Active Rules Inspected
          </span>
        </div>

        <div className="space-y-3">
          {validationRules.map((rule) => {
            const isFatal = rule.severity === 'Fatal Error';
            const isClean = rule.affectedCount === 0;

            if (isClean) {
              return (
                <div
                  key={rule.id}
                  className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span className="font-mono font-semibold text-slate-800">{rule.ruleCode}:</span>
                    <span className="text-slate-600">{rule.description}</span>
                  </div>
                  <span className="text-emerald-700 font-semibold font-mono text-[11px]">
                    0 Exceptions (Verified Clean)
                  </span>
                </div>
              );
            }

            return (
              <div
                key={rule.id}
                className={`p-4 rounded-lg border space-y-3 ${
                  isFatal ? 'border-rose-200 bg-rose-50/30' : 'border-amber-200 bg-amber-50/30'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded ${
                      isFatal ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {rule.severity}
                    </span>
                    <span className="font-mono font-bold text-xs text-slate-900">{rule.ruleCode}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-xs font-medium text-slate-600">{rule.category}</span>
                  </div>

                  <span className="text-xs font-mono font-bold text-slate-800">
                    {rule.affectedCount} Student{rule.affectedCount > 1 ? 's' : ''} Affected
                  </span>
                </div>

                <p className="text-xs text-slate-700">
                  {rule.description}
                </p>

                <div className="p-3 bg-white rounded border border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-slate-500 font-medium">Resolution Guidance: </span>
                    <span className="text-slate-800">{rule.recommendation}</span>
                  </div>

                  {/* If this is the missing SSID error for Siddharth Rao, offer 1-click fix */}
                  {rule.affectedStudentIds.includes('stu-109') && (
                    <button
                      onClick={() => handleQuickFixSSID('stu-109')}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-xs transition-colors shrink-0 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>1-Click Assign Validated SSID</span>
                    </button>
                  )}

                  {!rule.affectedStudentIds.includes('stu-109') && rule.affectedStudentIds[0] && (
                    <button
                      onClick={() => {
                        setSelectedStudentId(rule.affectedStudentIds[0]);
                        setActiveModule('enrollment');
                      }}
                      className="inline-flex items-center gap-1 px-3 py-1 text-xs font-medium text-indigo-700 hover:bg-indigo-50 border border-indigo-200 rounded-md transition-colors shrink-0 cursor-pointer"
                    >
                      <span>Open Student Profile</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* State Extract Generation & Export Desk */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              Certified State Department Extract Generator
            </h2>
            <p className="text-xs text-slate-500">
              Produces certified data payloads matching state specification schemas
            </p>
          </div>
          <span className="text-xs font-mono font-medium text-indigo-600">
            Standard: {standard}
          </span>
        </div>

        {/* Extract Type Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {[
            { id: 'DEMO', title: 'Student Demographics (DEMO)', desc: 'SSID, race, language, FRL' },
            { id: 'SENR', title: 'Enrollment History (SENR)', desc: 'Entry codes, grade, cohort' },
            { id: 'SATS', title: 'Attendance Summary (SATS)', desc: 'ADA %, chronic absenteeism' },
            { id: 'SPED', title: 'Special Programs (SPED)', desc: 'IEP & Section 504 plans' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setExtractType(item.id as any);
                setGeneratedPayload(null);
              }}
              className={`p-3 rounded-lg border text-left transition-colors cursor-pointer ${
                extractType === item.id
                  ? 'border-indigo-600 bg-indigo-50/50 shadow-xs'
                  : 'border-slate-200 hover:bg-slate-50'
              }`}
            >
              <p className="font-bold text-slate-900">{item.title}</p>
              <p className="text-[10px] text-slate-500 mt-0.5">{item.desc}</p>
            </button>
          ))}
        </div>

        {/* Generate Trigger */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
          <div className="text-xs text-slate-600">
            Extract contains data for <strong className="font-mono">{students.length} students</strong> across Oakridge USD.
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleGenerateExtract}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Generate Payload Extract</span>
            </button>

            {generatedPayload && (
              <button
                onClick={handleDownloadExtract}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-xs transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>Download .JSON</span>
              </button>
            )}
          </div>
        </div>

        {/* Payload Preview */}
        {generatedPayload && (
          <div className="mt-4 pt-3 border-t border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-800">
                Official {standard} {extractType} Payload Preview:
              </span>
              <span className="text-[11px] font-mono text-slate-500">
                Format: Compliant JSON/REST Data Exchange
              </span>
            </div>
            <pre className="p-4 bg-slate-900 text-slate-100 rounded-lg font-mono text-[11px] overflow-x-auto max-h-72 border border-slate-800">
              {generatedPayload}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
