import React, { useState, useMemo } from 'react';
import { useSIS } from '../../context/SISContext';
import {
  BookOpen,
  Plus,
  FileSpreadsheet,
  Printer,
  ChevronRight,
  Sparkles,
  Sliders,
  Check,
  TrendingUp,
} from 'lucide-react';
import { Course, GradingType, Student } from '../../types/sis';
import { NewAssignmentModal } from './NewAssignmentModal';
import { ReportCardModal } from './ReportCardModal';

export const GradebookView: React.FC = () => {
  const {
    courses,
    selectedCourseId,
    setSelectedCourseId,
    assignments,
    grades,
    students,
    updateGrade,
  } = useSIS();

  const [activeCourse, setActiveCourse] = useState<Course>(() => {
    return courses.find((c) => c.id === selectedCourseId) || courses[0];
  });

  const [gradingMode, setGradingMode] = useState<GradingType>(activeCourse.gradingType);
  const [newAssignmentOpen, setNewAssignmentOpen] = useState(false);
  const [reportCardStudent, setReportCardStudent] = useState<Student | null>(null);

  // Sync when selected course changes
  const handleCourseChange = (courseId: string) => {
    setSelectedCourseId(courseId);
    const found = courses.find((c) => c.id === courseId);
    if (found) {
      setActiveCourse(found);
      setGradingMode(found.gradingType);
    }
  };

  // Filter students enrolled in this course grade level (e.g., 10th grade)
  const enrolledStudents = useMemo(() => {
    return students.filter((s) => s.gradeLevel === activeCourse.gradeLevel);
  }, [students, activeCourse]);

  // Filter assignments for this course
  const courseAssignments = useMemo(() => {
    return assignments.filter((a) => a.courseId === activeCourse.id);
  }, [assignments, activeCourse]);

  // Calculate overall student grade in this course
  const calculateStudentOverall = (studentId: string) => {
    const studentCourseGrades = grades.filter(
      (g) => g.studentId === studentId && g.courseId === activeCourse.id
    );

    if (gradingMode === 'standards_based') {
      const standardScores = studentCourseGrades
        .map((g) => g.standardMastery || g.score || 0)
        .filter((s) => s > 0);
      if (standardScores.length === 0) return { text: 'N/A', num: 0 };
      const avg = standardScores.reduce((a, b) => a + b, 0) / standardScores.length;
      return { text: `${avg.toFixed(1)} / 4.0`, num: avg };
    } else {
      let earnedPoints = 0;
      let totalPossible = 0;
      courseAssignments.forEach((asg) => {
        const entry = studentCourseGrades.find((g) => g.assignmentId === asg.id);
        if (entry && entry.score !== null) {
          earnedPoints += entry.score;
          totalPossible += asg.maxPoints;
        }
      });
      if (totalPossible === 0) return { text: '100%', letter: 'A', num: 100 };
      const pct = (earnedPoints / totalPossible) * 100;
      const letter = pct >= 90 ? 'A' : pct >= 80 ? 'B' : pct >= 70 ? 'C' : pct >= 60 ? 'D' : 'F';
      return { text: `${pct.toFixed(1)}%`, letter, num: pct };
    }
  };

  // Calculate class average
  const classAverage = useMemo(() => {
    if (enrolledStudents.length === 0) return 0;
    const totals = enrolledStudents.map((s) => calculateStudentOverall(s.id).num);
    const sum = totals.reduce((a, b) => a + b, 0);
    return (sum / enrolledStudents.length).toFixed(1);
  }, [enrolledStudents, courseAssignments, grades, gradingMode]);

  return (
    <div className="space-y-4">
      {/* Header with Course Switcher & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>Teacher Gradebook</span>
            <span>·</span>
            <span className="font-semibold text-slate-800">{activeCourse.teacherName}</span>
            <span>·</span>
            <span>Period {activeCourse.period}</span>
          </div>
          <div className="mt-1 flex items-center gap-3">
            <h1 className="text-xl font-bold tracking-tight text-slate-900">
              {activeCourse.name}
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 bg-slate-100 border border-slate-200 text-slate-600 rounded">
              {activeCourse.code}
            </span>
          </div>
        </div>

        {/* Right Action buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Grading Paradigm Segmented Toggle */}
          <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => setGradingMode('traditional')}
              className={`px-3 py-1 font-medium rounded-md transition-colors cursor-pointer ${
                gradingMode === 'traditional'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Traditional (A–F)
            </button>
            <button
              onClick={() => setGradingMode('standards_based')}
              className={`px-3 py-1 font-medium rounded-md transition-colors cursor-pointer ${
                gradingMode === 'standards_based'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Standards-Based (1–4)
            </button>
          </div>

          <button
            onClick={() => setNewAssignmentOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Assessment</span>
          </button>
        </div>
      </div>

      {/* Course Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {courses.map((course) => {
          const isSelected = course.id === activeCourse.id;
          return (
            <button
              key={course.id}
              onClick={() => handleCourseChange(course.id)}
              className={`px-3 py-1.5 rounded-lg border text-left whitespace-nowrap transition-colors cursor-pointer ${
                isSelected
                  ? 'bg-white border-indigo-500 font-semibold text-indigo-700 shadow-xs ring-1 ring-indigo-500'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span>{course.name}</span>
              <span className="ml-1.5 text-[10px] text-slate-400 font-mono">P{course.period}</span>
            </button>
          );
        })}
      </div>

      {/* Class Metric Highlights Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs text-xs">
        <div>
          <span className="text-slate-500 text-[11px]">Class Mastery Average</span>
          <div className="mt-0.5 flex items-baseline gap-1.5">
            <span className="text-lg font-bold font-mono text-slate-900">
              {classAverage}{gradingMode === 'standards_based' ? ' / 4.0' : '%'}
            </span>
            <span className="text-[10px] text-emerald-600 font-medium">On Track</span>
          </div>
        </div>
        <div>
          <span className="text-slate-500 text-[11px]">Enrolled Students</span>
          <p className="mt-0.5 text-lg font-bold font-mono text-slate-900">
            {enrolledStudents.length} Students
          </p>
        </div>
        <div>
          <span className="text-slate-500 text-[11px]">Graded Tasks Published</span>
          <p className="mt-0.5 text-lg font-bold font-mono text-slate-900">
            {courseAssignments.length} Assessments
          </p>
        </div>
        <div>
          <span className="text-slate-500 text-[11px]">Grading Policy Scale</span>
          <p className="mt-0.5 text-xs font-semibold text-slate-800">
            {gradingMode === 'standards_based' ? '4-Level Standards Rubric' : 'Weighted: 60% Sum / 40% Form'}
          </p>
        </div>
      </div>

      {/* High-Speed Spreadsheet Grade Grid */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4 sticky left-0 bg-slate-50 z-10 w-52 shadow-xs">
                  Student Name
                </th>
                <th className="py-3 px-3 text-center w-24">
                  Overall Mark
                </th>

                {/* Assignment Columns */}
                {courseAssignments.map((asg) => (
                  <th key={asg.id} className="py-3 px-3 min-w-[140px] text-center border-l border-slate-100">
                    <div className="space-y-0.5">
                      <div className="font-bold text-slate-800 truncate" title={asg.title}>
                        {asg.title}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono flex items-center justify-center gap-1">
                        <span>{asg.category}</span>
                        <span>·</span>
                        <span>{asg.maxPoints} pts</span>
                      </div>
                      {asg.standards && asg.standards[0] && (
                        <div className="text-[9px] font-mono text-indigo-600 bg-indigo-50/70 rounded px-1 py-0.2 inline-block">
                          {asg.standards[0]}
                        </div>
                      )}
                    </div>
                  </th>
                ))}

                <th className="py-3 px-3 text-right sticky right-0 bg-slate-50 z-10 w-24">
                  Report Card
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {enrolledStudents.map((student) => {
                const overall = calculateStudentOverall(student.id);

                return (
                  <tr key={student.id} className="hover:bg-indigo-50/20 transition-colors">
                    {/* Student Name Sticky Column */}
                    <td className="py-2.5 px-4 sticky left-0 bg-white z-10 shadow-xs">
                      <div className="flex items-center gap-2.5">
                        <div className="w-6 h-6 rounded-full bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-[10px]">
                          {student.firstName[0]}
                          {student.lastName[0]}
                        </div>
                        <div>
                          <p className="font-semibold text-slate-900">
                            {student.lastName}, {student.firstName}
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono">
                            ID #{student.localId}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Overall Calculated Column */}
                    <td className="py-2.5 px-3 text-center tabular-nums font-mono font-bold">
                      <span className={`px-2 py-0.5 rounded text-xs ${
                        overall.num >= 85 || overall.num >= 3.5
                          ? 'bg-emerald-50 text-emerald-700'
                          : overall.num >= 70 || overall.num >= 2.5
                          ? 'bg-indigo-50 text-indigo-700'
                          : 'bg-amber-50 text-amber-700'
                      }`}>
                        {overall.text}
                      </span>
                    </td>

                    {/* Dynamic Assignment Grade Cells (Editable inline) */}
                    {courseAssignments.map((asg) => {
                      const gradeEntry = grades.find(
                        (g) => g.studentId === student.id && g.assignmentId === asg.id
                      );
                      const currentScore = gradeEntry ? gradeEntry.score : null;
                      const currentMastery = gradeEntry?.standardMastery || (currentScore ? Math.min(4, Math.max(1, Math.round(currentScore / 25))) : 3);

                      return (
                        <td key={asg.id} className="py-2 px-2 text-center border-l border-slate-100">
                          {gradingMode === 'standards_based' ? (
                            /* Standards-based 4-level pill selector */
                            <div className="inline-flex rounded-md border border-slate-200 overflow-hidden text-[10px] font-mono">
                              {[1, 2, 3, 4].map((level) => {
                                const isSelected = currentMastery === level;
                                return (
                                  <button
                                    key={level}
                                    type="button"
                                    onClick={() => updateGrade(student.id, asg.id, level, level as any)}
                                    title={
                                      level === 4
                                        ? '4: Exceeds Standard'
                                        : level === 3
                                        ? '3: Proficient / Meets'
                                        : level === 2
                                        ? '2: Developing'
                                        : '1: Emerging'
                                    }
                                    className={`px-2 py-1 font-bold transition-colors cursor-pointer ${
                                      isSelected
                                        ? level === 4
                                          ? 'bg-emerald-600 text-white'
                                          : level === 3
                                          ? 'bg-indigo-600 text-white'
                                          : level === 2
                                          ? 'bg-amber-500 text-white'
                                          : 'bg-rose-500 text-white'
                                        : 'bg-white text-slate-500 hover:bg-slate-100'
                                    }`}
                                  >
                                    {level}
                                  </button>
                                );
                              })}
                            </div>
                          ) : (
                            /* Traditional numeric input */
                            <div className="flex items-center justify-center gap-1">
                              <input
                                type="number"
                                min={0}
                                max={asg.maxPoints}
                                value={currentScore !== null && currentScore !== undefined ? currentScore : ''}
                                placeholder="—"
                                onChange={(e) => {
                                  const val = e.target.value === '' ? null : Number(e.target.value);
                                  updateGrade(student.id, asg.id, val);
                                }}
                                className="w-14 px-1.5 py-1 text-center font-mono font-medium text-xs border border-slate-200 rounded focus:border-indigo-500 focus:bg-indigo-50/20 focus:outline-none"
                              />
                              <span className="text-[10px] text-slate-400 font-mono">
                                /{asg.maxPoints}
                              </span>
                            </div>
                          )}
                        </td>
                      );
                    })}

                    {/* Report Card preview action */}
                    <td className="py-2.5 px-3 text-right sticky right-0 bg-white z-10">
                      <button
                        onClick={() => setReportCardStudent(student)}
                        title="Generate official student report card"
                        className="p-1 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors cursor-pointer"
                      >
                        <Printer className="w-4 h-4 inline" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer with instant autosave indicator */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Real-time grade synchronization enabled (Zero manual save required)</span>
          </div>
          <span className="text-[11px] font-mono">
            Scale: {gradingMode === 'standards_based' ? '4 Exceeds · 3 Proficient · 2 Developing · 1 Emerging' : 'A: 90-100 · B: 80-89 · C: 70-79 · D: 60-69 · F: <60'}
          </span>
        </div>
      </div>

      {/* Modals */}
      <NewAssignmentModal
        courseId={activeCourse.id}
        isOpen={newAssignmentOpen}
        onClose={() => setNewAssignmentOpen(false)}
      />

      {reportCardStudent && (
        <ReportCardModal
          student={reportCardStudent}
          isOpen={true}
          onClose={() => setReportCardStudent(null)}
        />
      )}
    </div>
  );
};
