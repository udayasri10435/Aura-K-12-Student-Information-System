import React from 'react';
import { useSIS } from '../../context/SISContext';
import { X, Printer, Download, Award, CheckCircle } from 'lucide-react';
import { Student } from '../../types/sis';

interface ReportCardModalProps {
  student: Student;
  isOpen: boolean;
  onClose: () => void;
}

export const ReportCardModal: React.FC<ReportCardModalProps> = ({
  student,
  isOpen,
  onClose,
}) => {
  const { courses, grades, attendance } = useSIS();

  if (!isOpen) return null;

  const studentGrades = grades.filter((g) => g.studentId === student.id);
  const studentAttendance = attendance.filter((a) => a.studentId === student.id);
  const totalAbsences = studentAttendance.filter((a) => a.status.startsWith('absent')).length;
  const totalTardies = studentAttendance.filter((a) => a.status === 'tardy').length;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="w-full max-w-3xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Top Action Bar (hidden in print) */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-slate-200 bg-slate-50 no-print">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-bold text-slate-900">
              Official Term Report Card & Academic Transcript
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Official Copy</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Document Area */}
        <div className="p-8 overflow-y-auto space-y-6 text-slate-900 print:p-0 print:m-0">
          {/* Official Letterhead */}
          <div className="border-b-2 border-slate-900 pb-4 flex justify-between items-start">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-slate-500 font-mono">
                Oakridge Unified School District
              </p>
              <h1 className="text-xl font-bold tracking-tight text-slate-900 mt-0.5">
                {student.schoolLevel} School Official Report of Progress
              </h1>
              <p className="text-xs text-slate-500">
                Accredited by Western Association of Schools and Colleges (WASC)
              </p>
            </div>
            <div className="text-right text-xs font-mono">
              <p className="font-bold text-slate-900">Academic Year 2026–2027</p>
              <p className="text-slate-500">Fall Semester Midterm Record</p>
              <p className="text-slate-400 text-[10px]">Issued: Sept 29, 2026</p>
            </div>
          </div>

          {/* Student Dossier Matrix */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 rounded-lg border border-slate-200 text-xs">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Student Legal Name</span>
              <p className="font-bold text-slate-900">{student.lastName}, {student.firstName}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Local District ID</span>
              <p className="font-mono font-medium text-slate-900">#{student.localId}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold">State Student ID (SSID)</span>
              <p className="font-mono font-medium text-slate-900">{student.ssid || 'PENDING'}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Grade / Counselor</span>
              <p className="font-medium text-slate-900">Gr {student.gradeLevel} · {student.counselor}</p>
            </div>
          </div>

          {/* Academic Coursework Table */}
          <div className="border border-slate-300 rounded-lg overflow-hidden">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-300 text-slate-700 font-bold uppercase text-[10px] tracking-wider">
                  <th className="py-2.5 px-3">Course / Code</th>
                  <th className="py-2.5 px-3">Teacher</th>
                  <th className="py-2.5 px-2 text-center">Period</th>
                  <th className="py-2.5 px-2 text-center">Credits</th>
                  <th className="py-2.5 px-3 text-right">Progress</th>
                  <th className="py-2.5 px-3 text-right">Mark</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {courses.map((course) => {
                  const courseGrades = studentGrades.filter((g) => g.courseId === course.id);
                  const total = courseGrades.reduce((acc, g) => acc + (g.score || 0), 0);
                  const letter = total > 85 ? 'A' : total > 70 ? 'B' : total > 50 ? 'C' : 'P';
                  const pct = total > 85 ? '94%' : total > 70 ? '86%' : '78%';

                  return (
                    <tr key={course.id}>
                      <td className="py-2.5 px-3">
                        <span className="font-bold text-slate-900">{course.name}</span>
                        <span className="text-[11px] text-slate-500 font-mono ml-2">({course.code})</span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">{course.teacherName}</td>
                      <td className="py-2.5 px-2 text-center font-mono">{course.period}</td>
                      <td className="py-2.5 px-2 text-center font-mono">5.0</td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                        {course.gradingType === 'standards_based' ? 'Mastery Level 4' : pct}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900 text-sm">
                        {course.gradingType === 'standards_based' ? '4.0' : letter}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Academic Summary & Attendance Statistics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 border border-slate-200 rounded-lg space-y-1.5 text-xs">
              <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider text-slate-500">
                Cumulative Academic Standing
              </h4>
              <div className="flex justify-between">
                <span className="text-slate-600">Cumulative Weighted GPA:</span>
                <span className="font-mono font-bold text-slate-900">{student.cumulativeGpa.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Total Graduation Credits Earned:</span>
                <span className="font-mono font-bold text-slate-900">{student.creditsEarned} / 220.0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Academic Honors Standing:</span>
                <span className="font-semibold text-emerald-700">Dean's Honor Roll Eligible</span>
              </div>
            </div>

            <div className="p-4 border border-slate-200 rounded-lg space-y-1.5 text-xs">
              <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider text-slate-500">
                Term Attendance Audit (ADA)
              </h4>
              <div className="flex justify-between">
                <span className="text-slate-600">Average Daily Attendance:</span>
                <span className="font-mono font-bold text-slate-900">{student.attendanceRate.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Excused & Unexcused Absences:</span>
                <span className="font-mono font-medium text-slate-900">{totalAbsences} days</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Tardy Instances:</span>
                <span className="font-mono font-medium text-slate-900">{totalTardies} periods</span>
              </div>
            </div>
          </div>

          {/* Official Seal and Signature Line */}
          <div className="pt-8 border-t border-slate-300 flex items-center justify-between text-xs text-slate-500">
            <div className="space-y-1">
              <div className="w-48 border-b border-slate-400 h-6" />
              <p className="font-medium text-slate-700">Dr. Karen Vance, Principal</p>
              <p className="text-[10px]">Oakridge Unified School District</p>
            </div>

            <div className="text-right">
              <div className="inline-block p-3 border-2 border-slate-400 rounded-full text-center font-mono text-[9px] uppercase tracking-wider text-slate-500">
                Official District<br />Registrar Seal
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end no-print">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
          >
            Close Report Card
          </button>
        </div>
      </div>
    </div>
  );
};
