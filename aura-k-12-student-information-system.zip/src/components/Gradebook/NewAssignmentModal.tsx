import React, { useState } from 'react';
import { useSIS } from '../../context/SISContext';
import { X, Plus, BookOpen } from 'lucide-react';
import { AssignmentCategory } from '../../types/sis';

interface NewAssignmentModalProps {
  courseId: string;
  isOpen: boolean;
  onClose: () => void;
}

export const NewAssignmentModal: React.FC<NewAssignmentModalProps> = ({
  courseId,
  isOpen,
  onClose,
}) => {
  const { addAssignment, courses } = useSIS();
  const currentCourse = courses.find((c) => c.id === courseId);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<AssignmentCategory>('Summative');
  const [dueDate, setDueDate] = useState('2026-10-04');
  const [maxPoints, setMaxPoints] = useState<number>(50);
  const [standardCode, setStandardCode] = useState('HS-LS1-5');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    addAssignment({
      courseId,
      title: title.trim(),
      category,
      dueDate,
      maxPoints: Number(maxPoints) || 50,
      standards: standardCode ? [standardCode.trim()] : undefined,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Create New Graded Assessment
            </h2>
            <p className="text-xs text-slate-500">
              {currentCourse?.name} ({currentCourse?.code})
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-medium text-slate-700">Assignment Title *</label>
            <input
              type="text"
              required
              placeholder="e.g. Molecular Genetics Exam / Unit 2 Synthesis"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1 w-full px-3 py-2 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-medium text-slate-700">Assessment Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
              >
                <option value="Summative">Summative (60% Weight)</option>
                <option value="Formative">Formative (40% Weight)</option>
                <option value="Homework">Homework / Practice</option>
                <option value="Project">Performance Task / Project</option>
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700">Due Date</label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
              >
              </input>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-medium text-slate-700">
                {currentCourse?.gradingType === 'standards_based' ? 'Mastery Scale' : 'Maximum Points'}
              </label>
              <input
                type="number"
                min={1}
                max={1000}
                value={maxPoints}
                onChange={(e) => setMaxPoints(parseInt(e.target.value) || 0)}
                className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400">
                {currentCourse?.gradingType === 'standards_based' ? 'Typically 4 for mastery' : 'Point denominator'}
              </span>
            </div>
            <div>
              <label className="block font-medium text-slate-700">Aligned Academic Standard</label>
              <input
                type="text"
                value={standardCode}
                onChange={(e) => setStandardCode(e.target.value)}
                placeholder="e.g. HS-LS1-5 or CCSS.ELA-LITERACY.RL.9-10.1"
                className="mt-1 w-full px-3 py-1.5 text-xs font-mono border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-md shadow-xs transition-colors cursor-pointer"
            >
              Publish Assignment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
