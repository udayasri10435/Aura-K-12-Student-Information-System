import React, { useState } from 'react';
import { useSIS } from '../../context/SISContext';
import {
  Users,
  Calendar,
  BookOpen,
  Clock,
  CheckCircle,
  AlertCircle,
  FileText,
  Mail,
  Printer,
  Plus,
  Send,
  CreditCard,
  Bell,
} from 'lucide-react';
import { ReportCardModal } from '../Gradebook/ReportCardModal';

export const ParentPortalView: React.FC = () => {
  const {
    students,
    courses,
    grades,
    attendance,
    absenceNotes,
    submitParentAbsenceNote,
    selectedParentStudentId,
    setSelectedParentStudentId,
  } = useSIS();

  // The Lin Family has Maya Lin (stu-101, Grade 10) and Leo Lin (stu-102, Grade 7)
  const familyStudents = students.filter(
    (s) => s.guardians.some((g) => g.email.includes('lin@') || g.name.includes('Lin'))
  );

  const activeStudent = students.find((s) => s.id === selectedParentStudentId) || familyStudents[0] || students[0];

  const [activeTab, setActiveTab] = useState<'academics' | 'schedule' | 'attendance' | 'notes'>('academics');
  const [absenceModalOpen, setAbsenceModalOpen] = useState(false);
  const [reportCardOpen, setReportCardOpen] = useState(false);

  // New Absence Note Form State
  const [noteStartDate, setNoteStartDate] = useState('2026-10-05');
  const [noteEndDate, setNoteEndDate] = useState('2026-10-05');
  const [noteReason, setNoteReason] = useState<'Illness' | 'Medical Appointment' | 'Bereavement' | 'Religious Observance' | 'Family Emergency' | 'Other'>('Medical Appointment');
  const [noteExplanation, setNoteExplanation] = useState('');
  const [noteHasDoctor, setNoteHasDoctor] = useState(true);

  // Active student grades & attendance
  const studentGrades = grades.filter((g) => g.studentId === activeStudent.id);
  const studentAttendance = attendance.filter((a) => a.studentId === activeStudent.id);
  const studentNotes = absenceNotes.filter((n) => n.studentId === activeStudent.id);

  const handleSendExcuseNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteExplanation.trim()) return;

    submitParentAbsenceNote({
      studentId: activeStudent.id,
      guardianName: activeStudent.guardians[0]?.name || 'Guardian',
      dateRequested: new Date().toISOString().split('T')[0],
      startDate: noteStartDate,
      endDate: noteEndDate,
      reason: noteReason,
      explanation: noteExplanation.trim(),
      doctorNoteAttached: noteHasDoctor,
    });

    setNoteExplanation('');
    setAbsenceModalOpen(false);
    setActiveTab('notes');
  };

  return (
    <div className="space-y-6">
      {/* Sibling Switcher & Guardian Welcome Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600">
              <Users className="w-3.5 h-3.5" />
              <span>Lin Family Guardian Portal</span>
              <span>·</span>
              <span className="text-slate-500 font-normal">Dr. Robert & Sarah Lin</span>
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 mt-1">
              Student Academic & Wellness Dashboard
            </h1>
          </div>

          {/* Sibling Picker Buttons */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Viewing Child:</span>
            <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs">
              {familyStudents.map((child) => (
                <button
                  key={child.id}
                  onClick={() => setSelectedParentStudentId(child.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 font-medium rounded-md transition-colors cursor-pointer ${
                    activeStudent.id === child.id
                      ? 'bg-white text-indigo-700 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-indigo-600" />
                  <span>{child.firstName}</span>
                  <span className="text-[10px] text-slate-400">Gr {child.gradeLevel}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Selected Student Banner Cards */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-4 border-t border-slate-100">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-500 text-[11px]">Cumulative GPA</span>
            <p className="mt-0.5 text-lg font-bold font-mono text-slate-900">
              {activeStudent.cumulativeGpa.toFixed(2)}
            </p>
            <span className="text-[10px] text-slate-400">Weighted Honors</span>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-500 text-[11px]">Attendance Rate</span>
            <p className="mt-0.5 text-lg font-bold font-mono text-emerald-700">
              {activeStudent.attendanceRate.toFixed(1)}%
            </p>
            <span className="text-[10px] text-emerald-700">Excellent Standing</span>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-500 text-[11px]">Meal / Cafeteria Account</span>
            <p className="mt-0.5 text-lg font-bold font-mono text-slate-900">
              $42.50
            </p>
            <button
              onClick={() => alert('Opening district payment portal to refill cafeteria funds.')}
              className="text-[10px] text-indigo-600 hover:text-indigo-800 font-medium cursor-pointer"
            >
              Add Funds →
            </button>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-500 text-[11px]">Homeroom & Counselor</span>
            <p className="mt-0.5 text-xs font-semibold text-slate-800 truncate">
              {activeStudent.counselor}
            </p>
            <span className="text-[10px] text-slate-400 truncate block">
              {activeStudent.homeroom}
            </span>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-2">
        <div className="flex items-center gap-1 sm:gap-4 text-xs font-medium">
          {[
            { id: 'academics', label: 'Classes & Grades' },
            { id: 'schedule', label: "Today's Schedule" },
            { id: 'attendance', label: 'Attendance Record' },
            { id: 'notes', label: `Absence Notes (${studentNotes.length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white font-semibold'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setAbsenceModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg border border-indigo-200 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Submit Absence Excuse</span>
          </button>
          <button
            onClick={() => setReportCardOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            <span>Term Report Card</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Classes & Grades */}
      {activeTab === 'academics' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {courses.map((course) => {
              const courseGrades = studentGrades.filter((g) => g.courseId === course.id);
              const totalScore = courseGrades.reduce((sum, g) => sum + (g.score || 0), 0);
              const letter = totalScore > 85 ? 'A' : totalScore > 70 ? 'B' : 'A-';
              const pct = totalScore > 85 ? '96%' : totalScore > 70 ? '88%' : '92%';

              return (
                <div
                  key={course.id}
                  className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[11px] font-mono text-slate-400">Period {course.period}</span>
                      <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                        {course.name}
                      </h3>
                      <p className="text-xs text-slate-500">
                        Instructor: {course.teacherName} · {course.room}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-2xl font-bold font-mono text-indigo-700">
                        {letter}
                      </span>
                      <p className="text-[10px] text-slate-400 font-mono">{pct}</p>
                    </div>
                  </div>

                  {/* Graded Assignments */}
                  <div className="pt-2 border-t border-slate-100">
                    <p className="text-[11px] font-semibold text-slate-600 mb-1.5">
                      Recent Graded Work:
                    </p>
                    {courseGrades.length > 0 ? (
                      <div className="space-y-1.5">
                        {courseGrades.slice(0, 2).map((g) => (
                          <div key={g.id} className="flex justify-between text-xs bg-slate-50 p-2 rounded">
                            <div>
                              <span className="font-medium text-slate-800">
                                {g.standardMastery ? `Standard Mastery: Level ${g.standardMastery}` : `Score: ${g.score} pts`}
                              </span>
                              {g.feedback && (
                                <p className="text-[10px] text-slate-500 italic mt-0.5">
                                  Teacher note: "{g.feedback}"
                                </p>
                              )}
                            </div>
                            <span className="text-[10px] text-emerald-600 font-semibold font-mono">
                              Graded
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400">No assessments recorded this week.</p>
                    )}
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span>Grading: {course.gradingType === 'standards_based' ? 'Standards Mastery' : 'Weighted'}</span>
                    <button
                      onClick={() => alert(`Email draft opened to ${course.teacherEmail}`)}
                      className="text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-1 cursor-pointer"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>Contact Teacher</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Today's Schedule Timeline */}
      {activeTab === 'schedule' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">
                Today's Instructional Bell Schedule
              </h2>
              <p className="text-xs text-slate-500">Tuesday, September 29, 2026 (Regular Schedule)</p>
            </div>
            <span className="text-xs font-mono font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              School In Session
            </span>
          </div>

          <div className="space-y-3">
            {[
              { period: 'Period 1', time: '08:00 AM – 08:52 AM', course: 'Biology Honors', room: 'Lab 204', teacher: 'M. Henderson', status: 'Completed (Present)' },
              { period: 'Period 2', time: '08:57 AM – 09:49 AM', course: 'World Literature 10', room: 'Room 114', teacher: 'Dr. R. Chen', status: 'Completed (Present)' },
              { period: 'Period 3', time: '09:54 AM – 10:46 AM', course: 'Algebra II & Trig', room: 'Lab 204', teacher: 'M. Henderson', status: 'In Session' },
              { period: 'Period 4', time: '10:51 AM – 11:43 AM', course: 'AP Computer Science', room: 'Comp Lab B', teacher: 'A. Rossi', status: 'Upcoming' },
              { period: 'Lunch', time: '11:43 AM – 12:23 PM', course: 'Campus Dining Commons', room: 'Courtyard', teacher: 'Staff Supervision', status: 'Upcoming' },
              { period: 'Period 6', time: '12:28 PM – 01:20 PM', course: 'Spanish III Honors', room: 'Room 108', teacher: 'S. Alvarez', status: 'Upcoming' },
            ].map((slot, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg border border-slate-200 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <div className="w-16 text-center font-mono font-bold text-xs text-indigo-700 bg-indigo-50 py-1 rounded">
                    {slot.period}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{slot.course}</h4>
                    <p className="text-[11px] text-slate-500">
                      {slot.room} · {slot.teacher}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-mono text-slate-600 block">{slot.time}</span>
                  <span className={`text-[10px] font-semibold ${
                    slot.status.includes('Completed')
                      ? 'text-emerald-700'
                      : slot.status.includes('In Session')
                      ? 'text-indigo-600'
                      : 'text-slate-400'
                  }`}>
                    {slot.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Attendance History */}
      {activeTab === 'attendance' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">
                Attendance & Punctuality Record
              </h2>
              <p className="text-xs text-slate-500">
                Recorded automatically by classroom teachers each period
              </p>
            </div>
            <div className="text-right font-mono">
              <span className="text-base font-bold text-emerald-700">{activeStudent.attendanceRate.toFixed(1)}%</span>
              <p className="text-[10px] text-slate-400">Cumulative ADA</p>
            </div>
          </div>

          <div className="space-y-2">
            {studentAttendance.length > 0 ? (
              studentAttendance.map((rec) => (
                <div key={rec.id} className="p-3 rounded-lg border border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-semibold text-slate-800">
                      Period {rec.period} Attendance
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Marked at {rec.markedAt} by {rec.markedBy} {rec.notes && `— "${rec.notes}"`}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="font-semibold text-emerald-700 uppercase tracking-wide">
                      {rec.status.replace('_', ' ')}
                    </span>
                    <p className="text-[10px] font-mono text-slate-400">{rec.date}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-6 text-center text-xs text-slate-500">
                No absences or tardies recorded. Perfect attendance standing!
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 4: Absence Notes Queue */}
      {activeTab === 'notes' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">
                Parent Submitted Absence Excuses
              </h2>
              <p className="text-xs text-slate-500">Official digital verification requests for school attendance office</p>
            </div>
            <button
              onClick={() => setAbsenceModalOpen(true)}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg cursor-pointer"
            >
              + Submit New Note
            </button>
          </div>

          <div className="space-y-3">
            {studentNotes.map((note) => (
              <div key={note.id} className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">{note.reason}</span>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                    note.status === 'Approved'
                      ? 'bg-emerald-50 text-emerald-700'
                      : note.status === 'Declined'
                      ? 'bg-rose-50 text-rose-700'
                      : 'bg-amber-50 text-amber-700'
                  }`}>
                    {note.status}
                  </span>
                </div>

                <p className="text-slate-700 italic">"{note.explanation}"</p>

                <div className="text-[11px] text-slate-500 flex justify-between pt-1 border-t border-slate-200/80">
                  <span>Dates: <strong className="font-mono text-slate-700">{note.startDate}</strong> to <strong className="font-mono text-slate-700">{note.endDate}</strong></span>
                  <span>Submitted on: {note.dateRequested}</span>
                </div>

                {note.doctorNoteAttached && (
                  <p className="text-[11px] text-emerald-700 flex items-center gap-1 font-medium">
                    <CheckCircle className="w-3.5 h-3.5" />
                    Doctor's note attached and on file
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Submit Absence Modal */}
      {absenceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Submit Verified Absence Excuse
                </h3>
                <p className="text-xs text-slate-500">
                  Student: {activeStudent.firstName} {activeStudent.lastName} (Grade {activeStudent.gradeLevel})
                </p>
              </div>
              <button
                onClick={() => setAbsenceModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSendExcuseNote} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700">Absence Start Date *</label>
                  <input
                    type="date"
                    required
                    value={noteStartDate}
                    onChange={(e) => setNoteStartDate(e.target.value)}
                    className="mt-1 w-full px-3 py-1.5 border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700">Absence End Date *</label>
                  <input
                    type="date"
                    required
                    value={noteEndDate}
                    onChange={(e) => setNoteEndDate(e.target.value)}
                    className="mt-1 w-full px-3 py-1.5 border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700">Absence Statutory Reason *</label>
                <select
                  value={noteReason}
                  onChange={(e) => setNoteReason(e.target.value as any)}
                  className="mt-1 w-full px-3 py-1.5 border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                >
                  <option value="Illness">Illness (Flu, cold, fever)</option>
                  <option value="Medical Appointment">Medical / Dental Specialist Appointment</option>
                  <option value="Bereavement">Bereavement / Family Memorial</option>
                  <option value="Religious Observance">Religious Observance Holiday</option>
                  <option value="Family Emergency">Family Emergency</option>
                  <option value="Other">Other Excused Absence</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700">Explanation for Attendance Office *</label>
                <textarea
                  required
                  rows={3}
                  value={noteExplanation}
                  onChange={(e) => setNoteExplanation(e.target.value)}
                  placeholder="Provide specific context for the attendance clerk..."
                  className="mt-1 w-full px-3 py-1.5 border border-slate-300 rounded-md focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <label className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                <input
                  type="checkbox"
                  checked={noteHasDoctor}
                  onChange={(e) => setNoteHasDoctor(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                />
                <div>
                  <span className="font-semibold text-slate-900">Include Certified Doctor's Excuse Note</span>
                  <p className="text-[11px] text-slate-500">Transmits clinical doctor note to school nurse & attendance office</p>
                </div>
              </label>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setAbsenceModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-white font-semibold bg-indigo-600 hover:bg-indigo-700 rounded-md shadow-xs cursor-pointer"
                >
                  Submit Excuse Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Report Card Modal */}
      {reportCardOpen && (
        <ReportCardModal
          student={activeStudent}
          isOpen={true}
          onClose={() => setReportCardOpen(false)}
        />
      )}
    </div>
  );
};
