import React, { useState, useMemo } from 'react';
import { useSIS } from '../../context/SISContext';
import {
  CalendarCheck,
  CheckCircle,
  Clock,
  AlertTriangle,
  UserCheck,
  Check,
  Filter,
  Save,
  MessageSquare,
} from 'lucide-react';
import { AttendanceStatusCode, Student } from '../../types/sis';

export const AttendanceTakeView: React.FC = () => {
  const {
    students,
    attendance,
    setAttendanceStatus,
    markAllPresent,
    selectedDate,
    setSelectedDate,
    selectedPeriod,
    setSelectedPeriod,
    courses,
  } = useSIS();

  const [filterHomeroomOnly, setFilterHomeroomOnly] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [activeNoteStudentId, setActiveNoteStudentId] = useState<string | null>(null);
  const [tempNote, setTempNote] = useState('');

  // 10th grade cohort for the active period/homeroom
  const activeStudents = useMemo(() => {
    return students.filter((s) => s.gradeLevel === '10');
  }, [students]);

  // Current records for today & period
  const currentPeriodRecords = useMemo(() => {
    return attendance.filter(
      (a) => a.date === selectedDate && a.period === selectedPeriod
    );
  }, [attendance, selectedDate, selectedPeriod]);

  // Status map for fast lookup
  const statusMap = useMemo(() => {
    const map = new Map<string, { status: AttendanceStatusCode; notes?: string; markedAt?: string }>();
    currentPeriodRecords.forEach((r) => {
      map.set(r.studentId, { status: r.status, notes: r.notes, markedAt: r.markedAt });
    });
    return map;
  }, [currentPeriodRecords]);

  // Summary counts
  const presentCount = activeStudents.filter((s) => {
    const st = statusMap.get(s.id)?.status;
    return st === 'present' || !st; // default assumed present
  }).length;

  const absentUnexcused = activeStudents.filter(
    (s) => statusMap.get(s.id)?.status === 'absent_unexcused'
  ).length;

  const absentExcused = activeStudents.filter(
    (s) => statusMap.get(s.id)?.status === 'absent_excused'
  ).length;

  const tardyCount = activeStudents.filter(
    (s) => statusMap.get(s.id)?.status === 'tardy'
  ).length;

  const periodADA = ((presentCount + tardyCount) / (activeStudents.length || 1)) * 100;

  const handleMarkAll = () => {
    markAllPresent(
      selectedDate,
      selectedPeriod,
      activeStudents.map((s) => s.id)
    );
  };

  const handleSaveNote = (studentId: string) => {
    const current = statusMap.get(studentId)?.status || 'present';
    setAttendanceStatus(studentId, selectedDate, selectedPeriod, current, tempNote);
    setActiveNoteStudentId(null);
    setTempNote('');
  };

  return (
    <div className="space-y-4">
      {/* Control Bar: Date, Period, and Quick Mark */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            {/* Date Selector */}
            <div>
              <label className="block text-[10px] uppercase font-semibold text-slate-400">Attendance Date</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="mt-0.5 px-2.5 py-1 text-xs font-mono font-medium border border-slate-200 rounded-md focus:border-indigo-500 focus:outline-none"
              />
            </div>

            {/* Period Selector Tabs */}
            <div>
              <label className="block text-[10px] uppercase font-semibold text-slate-400">Class Session / Period</label>
              <div className="mt-0.5 flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs">
                <button
                  onClick={() => setSelectedPeriod('homeroom')}
                  className={`px-2.5 py-1 font-medium rounded-md transition-colors cursor-pointer ${
                    selectedPeriod === 'homeroom'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Homeroom
                </button>
                {[1, 2, 3, 4, 6].map((p) => (
                  <button
                    key={p}
                    onClick={() => setSelectedPeriod(p)}
                    className={`px-2.5 py-1 font-medium rounded-md transition-colors cursor-pointer ${
                      selectedPeriod === p
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Period {p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Rapid Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAll}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Mark All Present</span>
            </button>
          </div>
        </div>

        {/* Live Period Counts Bar */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="text-slate-600">Present:</span>
              <strong className="font-mono text-slate-900">{presentCount}</strong>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span className="text-slate-600">Unexcused:</span>
              <strong className="font-mono text-rose-700">{absentUnexcused}</strong>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
              <span className="text-slate-600">Excused:</span>
              <strong className="font-mono text-sky-700">{absentExcused}</strong>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span className="text-slate-600">Tardy:</span>
              <strong className="font-mono text-amber-700">{tardyCount}</strong>
            </div>
          </div>

          <div className="text-xs">
            <span className="text-slate-500">Period ADA Rate: </span>
            <strong className="font-mono font-bold text-slate-900">{periodADA.toFixed(1)}%</strong>
          </div>
        </div>
      </div>

      {/* High-Density Roster Attendance Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
              <th className="py-3 px-4 w-60">Student / Identification</th>
              <th className="py-3 px-4">Attendance Status Code</th>
              <th className="py-3 px-4">Intervention & Tardy Notes</th>
              <th className="py-3 px-4 text-right">Timestamp</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {activeStudents.map((student) => {
              const record = statusMap.get(student.id);
              const currentStatus: AttendanceStatusCode = record ? record.status : 'present';
              const isChronic = student.attendanceRate < 90.0;

              return (
                <tr key={student.id} className="hover:bg-slate-50/70 transition-colors">
                  {/* Student Name */}
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-slate-700">
                        {student.firstName[0]}
                        {student.lastName[0]}
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                          <span>{student.lastName}, {student.firstName}</span>
                          {isChronic && (
                            <span className="text-[9px] font-bold text-amber-700 bg-amber-100 px-1 py-0.2 rounded" title="Under 90% statutory attendance">
                              SART Alert
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          ID #{student.localId} · {student.homeroom}
                        </div>
                      </div>
                    </div>
                  </td>

                  {/* Attendance Code Segmented Selector */}
                  <td className="py-2.5 px-4">
                    <div className="inline-flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs">
                      <button
                        type="button"
                        onClick={() => setAttendanceStatus(student.id, selectedDate, selectedPeriod, 'present')}
                        className={`px-2.5 py-1 font-semibold rounded-md transition-colors cursor-pointer ${
                          currentStatus === 'present'
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Present (P)
                      </button>
                      <button
                        type="button"
                        onClick={() => setAttendanceStatus(student.id, selectedDate, selectedPeriod, 'absent_unexcused')}
                        className={`px-2.5 py-1 font-semibold rounded-md transition-colors cursor-pointer ${
                          currentStatus === 'absent_unexcused'
                            ? 'bg-rose-600 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Unexcused (A-U)
                      </button>
                      <button
                        type="button"
                        onClick={() => setAttendanceStatus(student.id, selectedDate, selectedPeriod, 'absent_excused')}
                        className={`px-2.5 py-1 font-semibold rounded-md transition-colors cursor-pointer ${
                          currentStatus === 'absent_excused'
                            ? 'bg-sky-600 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Excused (A-E)
                      </button>
                      <button
                        type="button"
                        onClick={() => setAttendanceStatus(student.id, selectedDate, selectedPeriod, 'tardy')}
                        className={`px-2.5 py-1 font-semibold rounded-md transition-colors cursor-pointer ${
                          currentStatus === 'tardy'
                            ? 'bg-amber-500 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Tardy (T)
                      </button>
                      <button
                        type="button"
                        onClick={() => setAttendanceStatus(student.id, selectedDate, selectedPeriod, 'nurse')}
                        className={`px-2.5 py-1 font-semibold rounded-md transition-colors cursor-pointer ${
                          currentStatus === 'nurse'
                            ? 'bg-purple-600 text-white shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Clinic (N)
                      </button>
                    </div>
                  </td>

                  {/* Notes / Reason */}
                  <td className="py-2.5 px-4">
                    {activeNoteStudentId === student.id ? (
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          value={tempNote}
                          onChange={(e) => setTempNote(e.target.value)}
                          placeholder="e.g. Doctor note / late bus / dentist"
                          className="w-full px-2 py-1 text-xs border border-indigo-400 rounded focus:outline-none"
                        />
                        <button
                          onClick={() => handleSaveNote(student.id)}
                          className="p-1 bg-indigo-600 text-white rounded hover:bg-indigo-700 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="text-slate-600 text-xs italic">
                          {record?.notes || '—'}
                        </span>
                        <button
                          onClick={() => {
                            setActiveNoteStudentId(student.id);
                            setTempNote(record?.notes || '');
                          }}
                          className="p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
                          title="Add attendance remark"
                        >
                          <MessageSquare className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </td>

                  {/* Timestamp */}
                  <td className="py-2.5 px-4 text-right font-mono text-[11px] text-slate-400">
                    {record?.markedAt || '08:00 AM'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>
            Daily Average Daily Attendance (ADA) synchronized with state apportionment register.
          </span>
          <span className="font-mono">
            Session: {selectedDate} · Period {selectedPeriod}
          </span>
        </div>
      </div>
    </div>
  );
};
