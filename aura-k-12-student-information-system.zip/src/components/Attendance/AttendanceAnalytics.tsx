import React from 'react';
import { useSIS } from '../../context/SISContext';
import {
  TrendingUp,
  AlertTriangle,
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  Send,
  Calendar,
} from 'lucide-react';

export const AttendanceAnalytics: React.FC = () => {
  const {
    students,
    absenceNotes,
    updateAbsenceNoteStatus,
    setSelectedStudentId,
    setActiveModule,
  } = useSIS();

  const chronicallyAbsent = students.filter((s) => s.attendanceRate < 90.0);
  const totalStudents = students.length;
  const overallADA = (
    students.reduce((sum, s) => sum + s.attendanceRate, 0) / totalStudents
  ).toFixed(1);

  return (
    <div className="space-y-6">
      {/* 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Cumulative District ADA</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold tracking-tight text-emerald-700 font-mono">
              {overallADA}%
            </span>
            <span className="text-xs text-emerald-700 font-medium flex items-center">
              <TrendingUp className="w-3.5 h-3.5 mr-0.5" />
              Above 95.0% Target
            </span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Qualifies for maximum state per-pupil funding apportionment
          </p>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Chronic Absenteeism Rate</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold tracking-tight text-amber-700 font-mono">
              {((chronicallyAbsent.length / totalStudents) * 100).toFixed(1)}%
            </span>
            <span className="text-xs text-slate-500">
              ({chronicallyAbsent.length} students)
            </span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Statutory definition: Missing &ge; 10% of instructional days
          </p>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Parent Excuse Submissions</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold tracking-tight text-slate-900 font-mono">
              {absenceNotes.length} Total
            </span>
            <span className="text-xs text-indigo-600 font-medium">
              {absenceNotes.filter((n) => n.status === 'Pending').length} Pending
            </span>
          </div>
          <p className="mt-2 text-[11px] text-slate-400">
            Submitted with doctor verification through Parent Portal
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Parent Excuse Notes Review Queue */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-600" />
              <h2 className="text-sm font-semibold text-slate-900">
                Incoming Parent Absence Excuse Notes
              </h2>
            </div>
            <span className="text-xs font-mono text-slate-400">
              Attendance Clerk Desk
            </span>
          </div>

          <div className="space-y-3">
            {absenceNotes.map((note) => {
              const student = students.find((s) => s.id === note.studentId);
              return (
                <div
                  key={note.id}
                  className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2.5"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">
                          {student?.firstName} {student?.lastName}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          Gr {student?.gradeLevel} · ID #{student?.localId}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Submitted by <span className="font-medium text-slate-700">{note.guardianName}</span> on {note.dateRequested}
                      </p>
                    </div>

                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                      note.status === 'Approved'
                        ? 'bg-emerald-50 text-emerald-700'
                        : note.status === 'Declined'
                        ? 'bg-rose-50 text-rose-700'
                        : 'bg-amber-50 text-amber-700'
                    }`}>
                      {note.status}
                    </span>
                  </div>

                  <div className="p-2.5 bg-white rounded border border-slate-200 text-xs space-y-1">
                    <p className="font-semibold text-slate-800">
                      {note.reason} (Dates: {note.startDate} to {note.endDate})
                    </p>
                    <p className="text-slate-600 italic">
                      "{note.explanation}"
                    </p>
                    {note.doctorNoteAttached && (
                      <div className="pt-1 flex items-center gap-1.5 text-[11px] text-emerald-700 font-medium">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Medical practitioner note attached & verified</span>
                      </div>
                    )}
                  </div>

                  {note.status === 'Pending' ? (
                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        onClick={() => updateAbsenceNoteStatus(note.id, 'Declined', 'Attendance Clerk')}
                        className="px-3 py-1 text-xs font-medium text-slate-600 hover:bg-slate-200 rounded transition-colors cursor-pointer"
                      >
                        Decline
                      </button>
                      <button
                        onClick={() => updateAbsenceNoteStatus(note.id, 'Approved', 'Attendance Clerk')}
                        className="px-3.5 py-1 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded transition-colors cursor-pointer"
                      >
                        Approve & Convert to Excused
                      </button>
                    </div>
                  ) : (
                    <div className="text-[10px] text-slate-400">
                      Reviewed by {note.reviewedBy} at {note.reviewedAt}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Chronic Absenteeism & SART Watchlist */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <h2 className="text-sm font-semibold text-slate-900">
                Chronic Absenteeism Intervention (SART)
              </h2>
            </div>
            <span className="text-xs font-mono text-slate-400">
              Statutory &lt; 90%
            </span>
          </div>

          <div className="space-y-3">
            {chronicallyAbsent.map((s) => (
              <div
                key={s.id}
                className="p-3.5 rounded-lg border border-amber-200 bg-amber-50/40 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      {s.firstName} {s.lastName}
                    </h3>
                    <p className="text-[11px] text-slate-500 font-mono">
                      Grade {s.gradeLevel} · ID #{s.localId} · {s.homeroom}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-base font-bold font-mono text-amber-800">
                      {s.attendanceRate.toFixed(1)}% ADA
                    </span>
                    <p className="text-[10px] text-amber-700">11.5% Instructional Loss</p>
                  </div>
                </div>

                <p className="text-xs text-slate-600">
                  Guardian: {s.guardians[0]?.name} ({s.guardians[0]?.phone})
                </p>

                <div className="pt-2 border-t border-amber-200/60 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-500">
                    Intervention Level: Stage 2 SART Review
                  </span>
                  <button
                    onClick={() => {
                      setSelectedStudentId(s.id);
                      setActiveModule('enrollment');
                    }}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                  >
                    Open Student Dossier →
                  </button>
                </div>
              </div>
            ))}

            {chronicallyAbsent.length === 0 && (
              <div className="py-8 text-center text-xs text-slate-500">
                Zero students currently exceed the statutory chronic absenteeism threshold!
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
