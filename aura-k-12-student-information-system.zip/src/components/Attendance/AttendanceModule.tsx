import React, { useState } from 'react';
import { AttendanceTakeView } from './AttendanceTakeView';
import { AttendanceAnalytics } from './AttendanceAnalytics';
import { Calendar, BarChart3 } from 'lucide-react';

export const AttendanceModule: React.FC = () => {
  const [subTab, setSubTab] = useState<'take' | 'analytics'>('take');

  return (
    <div className="space-y-4">
      {/* Subtab navigation */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Attendance & Average Daily Attendance (ADA)
          </h1>
          <p className="text-xs text-slate-500">
            Real-time classroom session rosters, statutory funding calculation, and parent excuse note processing
          </p>
        </div>

        <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs">
          <button
            onClick={() => setSubTab('take')}
            className={`flex items-center gap-1.5 px-3 py-1.5 font-medium rounded-md transition-colors cursor-pointer ${
              subTab === 'take'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Classroom Roll Call</span>
          </button>
          <button
            onClick={() => setSubTab('analytics')}
            className={`flex items-center gap-1.5 px-3 py-1.5 font-medium rounded-md transition-colors cursor-pointer ${
              subTab === 'analytics'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>ADA & Parent Excuse Queue</span>
          </button>
        </div>
      </div>

      {subTab === 'take' ? <AttendanceTakeView /> : <AttendanceAnalytics />}
    </div>
  );
};
