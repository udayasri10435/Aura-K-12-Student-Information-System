export type SchoolLevel = 'Elementary' | 'Middle' | 'High';

export type EnrollmentStatus = 'Active' | 'Pending Review' | 'Withdrawn';

export interface Guardian {
  id: string;
  name: string;
  relationship: 'Mother' | 'Father' | 'Legal Guardian' | 'Grandparent' | 'Foster Parent';
  phone: string;
  email: string;
  isPrimary: boolean;
  canPickup: boolean;
  address?: string;
}

export interface StudentDocument {
  id: string;
  type: 'Birth Certificate' | 'Immunization Records' | 'Proof of Residency' | 'Home Language Survey' | 'Prior School Transcript';
  verified: boolean;
  verifiedBy?: string;
  verificationDate?: string;
  notes?: string;
}

export interface StudentPrograms {
  iep: boolean;
  iepReviewDate?: string;
  section504: boolean;
  ell: boolean; // English Language Learner
  primaryLanguage: string;
  freeReducedLunch: boolean;
  giftedTalented: boolean;
}

export interface Student {
  id: string;
  ssid: string; // State Student Identifier (e.g. 9-10 digit state unique ID)
  localId: string;
  firstName: string;
  lastName: string;
  preferredName?: string;
  dob: string;
  gender: 'Female' | 'Male' | 'Non-Binary' | 'Prefer not to say';
  gradeLevel: string; // 'K', '1', '2' ... '12'
  schoolLevel: SchoolLevel;
  homeroom: string;
  counselor: string;
  enrollmentStatus: EnrollmentStatus;
  enrollmentDate: string;
  guardians: Guardian[];
  emergencyContacts: { name: string; relation: string; phone: string }[];
  address: {
    street: string;
    city: string;
    state: string;
    zip: string;
  };
  programs: StudentPrograms;
  documents: StudentDocument[];
  cumulativeGpa: number;
  creditsEarned: number;
  attendanceRate: number; // e.g. 94.5%
  medicalNotes?: string;
  avatarUrl?: string;
}

export type GradingType = 'traditional' | 'standards_based';

export interface Course {
  id: string;
  code: string;
  name: string;
  department: string;
  teacherId: string;
  teacherName: string;
  teacherEmail: string;
  period: number;
  room: string;
  gradeLevel: string;
  gradingType: GradingType;
  credits: number;
  term: string; // 'Fall 2026'
}

export type AssignmentCategory = 'Summative' | 'Formative' | 'Homework' | 'Project';

export interface Assignment {
  id: string;
  courseId: string;
  title: string;
  category: AssignmentCategory;
  dueDate: string;
  maxPoints: number;
  weightPercent?: number;
  standards?: string[]; // e.g. ["MATH.HS.A-SSE.1", "MATH.HS.A-CED.2"]
}

export interface GradeEntry {
  id: string;
  studentId: string;
  assignmentId: string;
  courseId: string;
  score: number | null; // e.g., 47 out of 50
  standardMastery?: 1 | 2 | 3 | 4; // 4: Exceeds, 3: Proficient, 2: Developing, 1: Emerging
  isMissing?: boolean;
  isExcused?: boolean;
  feedback?: string;
  submittedAt?: string;
}

export type AttendanceStatusCode =
  | 'present'
  | 'absent_unexcused'
  | 'absent_excused'
  | 'tardy'
  | 'school_activity'
  | 'nurse';

export interface AttendanceRecord {
  id: string;
  studentId: string;
  date: string; // YYYY-MM-DD
  period: number | 'homeroom';
  status: AttendanceStatusCode;
  markedBy: string;
  markedAt: string;
  notes?: string;
}

export interface ParentAbsenceNote {
  id: string;
  studentId: string;
  guardianName: string;
  dateRequested: string;
  startDate: string;
  endDate: string;
  reason: 'Illness' | 'Medical Appointment' | 'Bereavement' | 'Religious Observance' | 'Family Emergency' | 'Other';
  explanation: string;
  doctorNoteAttached: boolean;
  status: 'Pending' | 'Approved' | 'Declined';
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface ComplianceValidationRule {
  id: string;
  ruleCode: string;
  severity: 'Fatal Error' | 'Warning' | 'Advisory';
  category: 'Demographics' | 'SSID' | 'Special Ed' | 'Attendance' | 'Course Enrollment';
  description: string;
  affectedCount: number;
  affectedStudentIds: string[];
  recommendation: string;
}

export type StateReportingStandard = 'CALPADS' | 'Ed-Fi' | 'PEIMS' | 'CRDC';

export type UserRole = 'admin' | 'teacher' | 'parent';

export type ActiveModule =
  | 'dashboard'
  | 'enrollment'
  | 'gradebook'
  | 'attendance'
  | 'parent_portal'
  | 'state_reporting';
